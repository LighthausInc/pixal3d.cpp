const {app,BrowserWindow,powerSaveBlocker,shell} = require('electron');
const {spawn} = require('node:child_process');
const {randomBytes} = require('node:crypto');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
let worker, win, wake, serviceUrl, serviceToken;
const root = app.isPackaged ? path.join(process.resourcesPath,'app') : path.join(__dirname,'..');
function launch(){
  const token=randomBytes(32).toString('hex');
  const configPath=process.env.LH3D_RUNTIME_CONFIG || path.join(process.platform==='win32'?(process.env.LOCALAPPDATA || os.homedir()):path.join(os.homedir(),'Library','Application Support'),'Lighthaus3DGen','runtime.json');
  let configured={};
  try{if(fs.existsSync(configPath))configured=JSON.parse(fs.readFileSync(configPath,'utf8'));}catch{require('electron').dialog.showErrorBox('Runtime configuration','The runtime.json file could not be read. Fix it before launching Studio.');app.quit();return;}
  const python=process.env.LH3D_PYTHON || configured.LH3D_PYTHON || (process.platform==='win32'?'python':fs.existsSync('/opt/homebrew/bin/python3')?'/opt/homebrew/bin/python3':'python3');
  worker=spawn(python,[path.join(root,'backend/server.py')],{cwd:root,windowsHide:true,env:{...process.env,LH3D_TOKEN:token},stdio:['ignore','pipe','pipe']});
  let pending='';
  worker.stdout.on('data', chunk=>{
    pending+=chunk.toString();
    const newline=pending.indexOf('\n');
    if(newline<0 || win) return;
    try {
      const {url}=JSON.parse(pending.slice(0,newline));
      if(!url.startsWith('http://127.0.0.1:')) throw new Error('Invalid worker URL');
      serviceUrl=url;serviceToken=token;
      win=new BrowserWindow({width:1480,height:1080,minWidth:1000,minHeight:700,show:!process.env.LH3D_SMOKE_OUT,backgroundColor:'#101216',autoHideMenuBar:true,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,backgroundThrottling:false}});
      if(process.env.LH3D_SMOKE_OUT){
        const errors=[];
        win.webContents.on('console-message',event=>{if(event.level==='error')errors.push(event.message);});
        win.webContents.on('did-finish-load',async()=>{
          try{
            let state;
            for(let i=0;i<40;i++){
              await new Promise(resolve=>setTimeout(resolve,500));
              state=await win.webContents.executeJavaScript(`({title:document.getElementById('asset-name').textContent,triangles:document.getElementById('triangles').textContent,previewReady:document.getElementById('empty-state').hidden,toast:document.getElementById('toast').textContent})`);
              if(state.previewReady)break;
            }
            await win.webContents.executeJavaScript("document.getElementById('wireframe').click(); document.getElementById('wireframe').click(); document.getElementById('reset-view').click();");
            await new Promise(resolve=>setTimeout(resolve,300));
            const capture=await win.webContents.capturePage();
            fs.writeFileSync(process.env.LH3D_SMOKE_OUT,capture.toPNG());
            fs.writeFileSync(process.env.LH3D_SMOKE_OUT+'.json',JSON.stringify({...state,errors},null,2));
            process.stdout.write(JSON.stringify({...state,errors})+'\n');
            app.quit();
          }catch(error){process.stderr.write(error.message+'\n');app.quit();}
        });
      }
      win.webContents.setWindowOpenHandler(({url:target})=>{
        if(target==='https://platform.tripo3d.ai/' || target==='https://github.com/pwilkin/trellis.cpp' || target==='https://github.com/LighthausInc/pixal3d.cpp') shell.openExternal(target);
        return {action:'deny'};
      });
      win.webContents.on('will-navigate',(event,target)=>{if(new URL(target).origin!==new URL(url).origin)event.preventDefault();});
      win.webContents.session.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false));
      win.loadURL(`${url}/#${token}`);
    } catch { app.quit(); }
  });
  worker.on('error',()=>{require('electron').dialog.showErrorBox('Python runtime needed','Set LH3D_PYTHON to a Python 3.11+ executable, then restart Studio.');app.quit();});
  worker.on('exit',()=>{if(!app.isQuitting)app.quit();});
  worker.stderr.on('data',chunk=>process.stderr.write(chunk));
}
if(!app.requestSingleInstanceLock())app.quit();
else {
  app.on('second-instance',()=>{win?.show();win?.focus();});
  app.whenReady().then(()=>{
    // Prevent system sleep only while actual job processing is in progress.
    launch();
    const timer=setInterval(async()=>{
      if(!win || win.isDestroyed())return;
      try {
        const busy=await win.webContents.executeJavaScript('Boolean(window.studioBusy)');
        if(busy && wake===undefined)wake=powerSaveBlocker.start('prevent-app-suspension');
        if(!busy && wake!==undefined){powerSaveBlocker.stop(wake);wake=undefined;}
      }catch{}
    },1000);
    app.on('before-quit',()=>clearInterval(timer));
  });
  app.on('window-all-closed',()=>app.quit());
  app.on('before-quit',event=>{
    if(wake!==undefined){powerSaveBlocker.stop(wake);wake=undefined;}
    if(app.isQuitting)return;
    app.isQuitting=true;
    if(!worker)return;
    event.preventDefault();
    (async()=>{
      try{
        if(serviceUrl)await fetch(serviceUrl+'/api/shutdown',{method:'POST',headers:{Authorization:'Bearer '+serviceToken,'Content-Type':'application/json'},body:'{}',signal:AbortSignal.timeout(1500)});
        if(worker.exitCode===null)await new Promise(resolve=>{const timeout=setTimeout(resolve,7000);worker.once('exit',()=>{clearTimeout(timeout);resolve();});});
      }catch{}
      finally{if(worker.exitCode===null)worker.kill();app.quit();}
    })();
  });
}
