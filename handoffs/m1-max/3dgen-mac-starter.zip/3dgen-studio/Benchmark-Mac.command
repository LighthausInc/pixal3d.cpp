#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON="${LH3D_PYTHON:-$(command -v python3 || true)}"
if [[ -z "$PYTHON" ]]; then echo 'Install native arm64 Python 3.11+ first.'; exit 1; fi
OUTPUT="${1:-$HOME/Library/Application Support/Lighthaus3DGen/benchmarks/aster-$(date +%Y%m%d-%H%M%S)}"
caffeinate -i "$PYTHON" tools/benchmark-native.py --output "$OUTPUT"
echo "Benchmark saved to $OUTPUT"
