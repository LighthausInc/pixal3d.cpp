# Lighthaus 3DGen Studio · prototype 0.1

A personal desktop workbench for native local 3D engines, premium APIs, and Blender. This is a new application codebase; it preserves the C++/GGML engines as external providers. Read [the architecture and roadmap](docs/PLAN.md) for the repository findings and proposed next steps.

## Run on Windows

Use **Start-Studio.ps1** in PowerShell. It finds an installed Python or the existing Codex Python runtime on this machine. A portable Windows build is under `dist/win-unpacked` when packaging has completed. Python 3.11+ and Blender remain external dependencies; Tripo/MCP also need Node. This is not a standalone installer.

```powershell
./Start-Studio.ps1
# Optional: use the demonstration history supplied alongside the source.
./Start-Studio.ps1 -State "$PSScriptRoot/demo-history"
```

If dependencies are missing, use Node **22.12+**, then `npm ci` and `npm start`. Electron's binary downloads on first launch. Set `LH3D_PYTHON` to your Python executable if it is not on PATH. `BLENDER_BIN` overrides automatic Blender discovery. No keys, weights or paid calls are required for the procedural provider.

## Run on Apple Silicon

Target: M1 Max with 64 GB unified memory. Install Node 22.12+, Python 3.11+ and Blender; run `npm ci`, then `bash Start-Studio.command` to apply the documented M1 attention setting. See [Mac validation](docs/MAC-VALIDATION.md). The same source has a macOS package target: `npm run pack:mac -- --arm64`. Run the packaging job on a Mac. macOS runtime execution, Metal inference, signing and notarization remain unverified in this Windows session.

## What works

- Real Blender procedural vessel, robot and pedestal creation, GLB export and an editable `.blend`.
- PBR viewport with orbit, fit, wireframe and auto rotation. Electron startup and the live interface have been exercised.
- Persistent SQLite job history; serialized workers; terminal states; manifest files and asset provenance sidecars.
- GLB import (self-contained files up to 100 MB) with source hashes, local Blender inspection and stable object inventory. External file/URL references are rejected before import.
- Blender material replacement targeted to an object and material slot, per-object decimation, and full-asset normalization to a height in metres with a base pivot. Each edit is a child asset version.
- Saved review verdicts and notes; authenticated GLB, `.blend`, and provenance downloads.
- Native CLI adapters for upstream TRELLIS.2 and the Pixal3D fork's `--sv-image` mode. These use separate CLI contracts; Windows CUDA inference validation is in progress.
- Tripo v3 text generation using the official SDK: submit, persist remote task ID, poll and download GLB. A real funded H3.1 generation succeeded: the walking observatory robot cost 20 credits ($0.20 equivalent), then passed Blender inspection and geometry reduction.
- Eight real MCP tools over stdio using the official MCP SDK and the same application service.

## Connect native engines

Use the actual native binaries and matching GGUF model directories. The `tools/install-native-windows.py --destination <directory>` helper downloads the pinned v0.8.1 CUDA release and Q8 weights (~10 GB), verifies their SHA-256 hashes and writes a model manifest. Inference verifies matching local model manifests and records file identities. Trust the manifest source independently; hashes alone are not signatures. The local workspace installation can be launched with `Start-Configured-Windows.ps1`. CUDA on Windows and Metal on Apple Silicon are selected by the engine build. The app passes `--require-gpu`.

```powershell
$env:TRELLIS_BIN='C:/engines/trellis/trellis-cli.exe'
$env:TRELLIS_MODELS='C:/models/trellis2-gguf'
$env:PIXAL3D_BIN='C:/engines/pixal3d/trellis-cli.exe'
$env:PIXAL3D_MODELS='C:/models/pixal3d-sv-gguf'
./Start-Studio.ps1
```

TRELLIS accepts PNG/JPEG reference images. Pixal3D SV requires a pre-matted RGBA PNG and uses 1024 or 1536 resolution. Multiview is not implemented in this application yet. Its integration should reuse Pixal3D's camera contract rather than inventing a new one.

## Connect Tripo

Open Connections and enter the API key in the password field, or set `TRIPO_API_KEY`, `TRIPO_MODEL`, and `TRIPO_ESTIMATE_USD` before launch. See [setup instructions](docs/TRIPO-SETUP.md). Obtain the model ID and pricing from your Tripo account. `TRIPO_ESTIMATE_USD` is a **user-configured reservation ceiling**, not a live quote or confirmed charge. The current connection form prefills the user-approved $5 reservation ceiling; this is not the actual expected price. Official H-series standard textured text generation is listed at 20 credits ($0.20) as checked on 2026-10-03. `LH3D_DAILY_CAP_USD` defaults to 5 USD per UTC day. Reservations are conservative. Definitive pre-submission rejections release reservations; ambiguous errors keep them pending reconciliation.

The cloud panel also offers a read-only API balance check that never submits generation. The UI requires a dry-run estimate and explicit approval of its displayed ceiling before submission. The server enforces the approval, daily reservation cap and input classification. Only `synthetic` and `licensed-reference` inputs may reach Tripo. Untagged and clinical inputs remain local. This is a routing policy, not an automated privacy classifier.

Keys entered in the password field are sent through the authenticated loopback service and held in its process environment for this session, then passed only to the Tripo helper. They are omitted from job records and from Blender/local-engine environments. OS keychain integration remains planned. The password field clears after connection; no key is stored in browser storage or application files.

## Apple Silicon setup

The [Mac validation guide](docs/MAC-VALIDATION.md) provides `Setup-Mac.command`, `Benchmark-Mac.command`, and `Build-Mac.command`. Setup builds the pinned v0.8.1 Metal engine and verifies a 7.24 GB Q8 weight set for 512-resolution inference. Runtime paths are saved for app launches; M1 attention settings apply automatically. The included robot benchmark records backend evidence, timings, platform and artifact identities. Windows execution is verified; actual M1 Max execution and the Mac application build still require that Mac. The starter archive is source/setup material, not a prebuilt Mac app.

## Live Blender workflow

The optional [Studio Link add-on](blender/studio_link.py) connects a running Blender scene. The UI and MCP can inspect objects, import an asset, create primitives, set transforms/materials, add reduction modifiers and pull a new version into Studio. [Setup and operation guide](docs/BLENDER-LIVE.md). Windows Blender 5.1 main-thread timer round trips are verified; Mac execution remains unverified.

## MCP

### Low-poly comparison

Select an original completed Tripo generation, then open **Compare low-poly methods** in the geometry panel. Both methods accept a triangle target between 500 and 20,000. Blender uses local decimation with the existing UVs. Tripo uses Smart Retopology v2.0 with texture baking at a listed cost of 30 credits ($0.30, checked 2026-10-03). The cloud action needs its own cost approval and shares the persistent daily budget. It reuses the original remote generation task; local edits cannot silently be replaced by the older remote mesh. Each result is a new child version.

The `tripo_retopology` MCP tool exposes the same operation with `job_id`, `face_limit`, and explicit `approved_usd`. Outputs in this comparison use triangle topology; native quad preservation/export is not yet implemented.

Start Studio first. Add the following server to an MCP client's configuration, replacing the source path and Node executable as needed. The MCP server reads the current local session descriptor from the same state directory as Studio; it does not expose a network listener.

```json
{
  "mcpServers": {
    "lighthaus-3dgen": {
      "command": "node",
      "args": ["C:/path/to/3dgen-studio/backend/mcp.mjs"]
    }
  }
}
```

If Studio uses `LH3D_STATE`, set the same environment variable for the MCP server. Tools: `import_asset`, `list_providers`, `estimate_cost`, `generate_asset`, `list_jobs`, `get_job`, `blender_op`, `tripo_retopology`, `blender_live_status`, `blender_live_command`, `submit_for_review`. Blender operations are restricted to the named operations; there is no arbitrary Python execution tool. Paid tool calls require `approved_usd`; agents must obtain user approval rather than infer it.

## Test and package

```powershell
python -m unittest discover -s tests -v
$env:LH3D_PYTHON=(Get-Command python).Source
npm test
npm run pack:win
```

The MCP integration test starts its own temporary server. In restrictive Windows sandboxes, set TEMP/TMP to a writable workspace directory. `LH3D_SMOKE_OUT` enables a hidden Electron self-test that saves a viewport screenshot and JSON diagnostics; normal launches show the app.

## Prototype limits

No texture painting/retargeting, local UV repair/baking, quad retopology, a graphical model installer, automatic resume/cache, cloud task reconciliation, remote workers, Rodin/fal adapters, or Unity-specific export is implemented. No engine C API has been added. Interrupted jobs are marked for review, never blindly resubmitted. Queued jobs can resume on startup; an active paid job can continue remotely after app shutdown. Its saved task ID is the starting point for reconciliation. A crash during the narrow submission-to-ID-write interval remains ambiguous and requires provider-account inspection.

Native provenance now includes verified model hashes, model revision, executable hash, declared version and license-status metadata. Provider-reported credit consumption is retained in provenance and successful charges reconcile local budget reservations at the documented USD conversion. Engine commit attestation and ambiguous-submission recovery remain unfinished. Blender import runs in a separate process with factory settings and `--disable-autoexec`; this does not constitute a complete OS-level security sandbox. Avoid untrusted assets until the hardening milestone. The renderer has context isolation, disabled Node integration, a CSP and restricted navigation; the service validates token, Origin and Host. The session descriptor is restricted by Unix mode where available and inherits the state directory's Windows ACL; Windows ACL hardening is pending. Single Studio instance is enforced by Electron, not by standalone Python service invocations.

The prototype source and workflow tests are provided as a starting point, with the platform and provider verification status recorded in `docs/VALIDATION.md`.
