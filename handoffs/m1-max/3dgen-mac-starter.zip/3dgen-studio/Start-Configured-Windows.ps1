# Workspace demonstration launcher. The portable source launcher remains Start-Studio.ps1.
$ErrorActionPreference = 'Stop'
$runtimeRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../work/native-runtime'))
$env:TRELLIS_BIN = Join-Path $runtimeRoot 'trellis-v0.8.1-cuda/trellis-cli.exe'
$env:TRELLIS_MODELS = Join-Path $runtimeRoot 'trellis-q8'
if (-not (Test-Path -LiteralPath $env:TRELLIS_BIN)) { throw 'Install the native Windows test runtime first; see README.' }
& (Join-Path $PSScriptRoot 'Start-Studio.ps1') -State (Join-Path $PSScriptRoot 'demo-history')
