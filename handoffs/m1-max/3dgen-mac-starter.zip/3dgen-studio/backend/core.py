"""Shared application service. No model frameworks required in the app process."""
import base64
from contextlib import contextmanager
import hashlib
import json
import math
import os
from pathlib import Path
import queue
import shutil
import sqlite3
import subprocess
import threading
import time
import uuid
import urllib.request
import urllib.error
from native import verify_native, sha256
from assets import inspect_glb, MAX_GLB_BYTES

ROOT = Path(__file__).resolve().parent.parent
PROVIDERS = {
    "blender": {"name": "Blender primitives", "kind": "procedural", "inputs": ["recipe"], "description": "Real geometry for testing and simple modeling. No AI inference."},
    "trellis": {"name": "TRELLIS.2 · native", "kind": "local", "inputs": ["image"], "description": "Upstream trellis.cpp · CUDA on Windows / Metal on Apple Silicon"},
    "pixal3d": {"name": "Pixal3D · native", "kind": "local", "inputs": ["image"], "description": "Pixal3D fork · single-view adapter; multiview planned"},
    "tripo": {"name": "Tripo · premium", "kind": "cloud", "inputs": ["text"], "description": "Official Tripo v3 SDK · text-to-3D with PBR"},
}

def default_state():
    if os.name == "nt":
        return Path(os.getenv("LOCALAPPDATA", str(Path.home()))) / "Lighthaus3DGen"
    return Path.home() / "Library/Application Support/Lighthaus3DGen"

def number(value, low, high, name, integer=False):
    if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value) or not low <= value <= high:
        raise ValueError(f"{name} must be between {low} and {high}")
    if integer and value != int(value):
        raise ValueError(f"{name} must be an integer")
    return int(value) if integer else float(value)

def validate(request):
    if not isinstance(request, dict):
        raise ValueError("Request must be an object")
    provider = request.get("provider", "blender")
    if provider not in PROVIDERS:
        raise ValueError("Unknown provider")
    kind = request.get("data_class", "unclassified")
    if kind not in ("synthetic", "licensed-reference", "clinical", "unclassified"):
        raise ValueError("Unknown data classification")
    if provider == "tripo" and kind not in ("synthetic", "licensed-reference"):
        raise ValueError("Cloud generation requires synthetic or licensed-reference input")
    prompt = request.get("prompt", "")
    if not isinstance(prompt, str) or len(prompt) > 2000:
        raise ValueError("Prompt must be text, at most 2000 characters")
    if provider == "tripo" and not prompt.strip():
        raise ValueError("Tripo requires a prompt")
    color = request.get("color", "#c78dff")
    if not isinstance(color, str) or len(color) != 7 or color[0] != "#" or any(c not in "0123456789abcdefABCDEF" for c in color[1:]):
        raise ValueError("Color must be #RRGGBB")
    resolution = request.get("resolution", 512)
    if resolution not in (512, 1024, 1536):
        raise ValueError("Resolution must be 512, 1024 or 1536")
    recipe = request.get("recipe", "vessel")
    if recipe not in ("vessel", "robot", "pedestal"):
        raise ValueError("Unknown procedural recipe")
    return {"provider": provider, "data_class": kind, "prompt": prompt.strip(), "color": color,
            "resolution": resolution, "recipe": recipe,
            "seed": number(request.get("seed", 42), 0, 2147483647, "Seed", True),
            "roughness": number(request.get("roughness", .32), 0, 1, "Roughness"),
            "metallic": number(request.get("metallic", .2), 0, 1, "Metallic")}

def find_blender():
    explicit = os.getenv("BLENDER_BIN")
    if explicit:
        return explicit if Path(explicit).is_file() else None
    found = shutil.which("blender")
    if found:
        return found
    for parent in (Path("C:/Program Files/Blender Foundation"), Path("/Applications")):
        candidates = sorted(parent.glob("Blender */blender.exe"), reverse=True) if os.name == "nt" else list(parent.glob("Blender.app/Contents/MacOS/Blender"))
        if candidates:
            return str(candidates[0])
    return None

def local_command(provider, image, output, request):
    prefix = "TRELLIS" if provider == "trellis" else "PIXAL3D"
    binary, models = os.getenv(prefix + "_BIN"), os.getenv(prefix + "_MODELS")
    if not binary or not Path(binary).is_file() or not models or not Path(models).is_dir():
        raise ValueError(f"Configure {prefix}_BIN and {prefix}_MODELS first")
    args = [binary, str(image), str(output), "--models", models, "--res", str(request["resolution"]),
            "--seed", str(request["seed"]), "--require-gpu"]
    if provider == "pixal3d":
        # Fork 0.10 SV mode has its own crop/camera preparation and radian FOV contract.
        args = [binary, "--sv-image", str(image), str(output), "--models", models,
                "--res", str(max(1024, request["resolution"])), "--seed", str(request["seed"]), "--require-gpu"]
    return args

class Studio:
    def __init__(self, state=None, start_worker=True):
        self.state = Path(state or os.getenv("LH3D_STATE", default_state())).resolve()
        self.state.mkdir(parents=True, exist_ok=True)
        self.db = self.state / "studio.sqlite"
        self.lock = threading.RLock()
        self.stop = threading.Event()
        self.pending = queue.Queue()
        self.process = None
        self.active_job = None
        self.worker = None
        with self.connect() as db:
            db.execute("CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, record TEXT NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS spend (id TEXT PRIMARY KEY, day TEXT, amount REAL)")
        if start_worker:
            # Interrupted work is visible and never blindly resubmitted to a paid provider.
            for job in self.list_jobs():
                if job["status"] == "running":
                    job.update(status="interrupted", stage="Interrupted; review before retry")
                    self.save(job)
                elif job["status"] == "queued":
                    self.pending.put(job["id"])
            self.worker = threading.Thread(target=self.work, daemon=True)
            self.worker.start()

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.db, timeout=15)
        db.execute("PRAGMA busy_timeout=15000")
        try:
            with db:
                yield db
        finally:
            db.close()

    def save(self, record):
        with self.lock, self.connect() as db:
            db.execute("INSERT OR REPLACE INTO jobs VALUES (?,?)", (record["id"], json.dumps(record)))
        folder = self.state / record["id"]
        folder.mkdir(exist_ok=True)
        temp = folder / "manifest.tmp"
        with self.lock:
            temp.write_text(json.dumps(record, indent=2), encoding="utf-8")
            temp.replace(folder / "manifest.json")
            if record["status"] == "succeeded":
                (folder / "asset.provenance.json").write_text(json.dumps(record, indent=2), encoding="utf-8")

    def get(self, job_id):
        with self.connect() as db:
            row = db.execute("SELECT record FROM jobs WHERE id=?", (job_id,)).fetchone()
        if row is None:
            raise ValueError("Job not found")
        return json.loads(row[0])

    def list_jobs(self):
        with self.connect() as db:
            rows = db.execute("SELECT record FROM jobs ORDER BY rowid DESC LIMIT 100").fetchall()
        return [json.loads(r[0]) for r in rows]

    def capabilities(self):
        result = []
        for key, spec in PROVIDERS.items():
            if key == "blender":
                ready = bool(find_blender())
                reason = "Ready" if ready else "Install Blender or set BLENDER_BIN"
            elif key == "tripo":
                ready = bool(os.getenv("TRIPO_API_KEY") and os.getenv("TRIPO_ESTIMATE_USD") and os.getenv("TRIPO_MODEL"))
                reason = "Configured · approval required" if ready else "Set API key, model and cost estimate"
            else:
                prefix = key.upper()
                ready = bool(os.getenv(prefix + "_BIN") and Path(os.getenv(prefix + "_BIN")).is_file() and Path(os.getenv(prefix + "_MODELS", "__missing__")).is_dir())
                reason = "Configured · model hashes checked before inference" if ready else "Configure engine binary and model directory"
            result.append({"id": key, **spec, "ready": ready, "reason": reason})
        return result

    def configure_tripo(self, raw):
        key = raw.get('api_key', '')
        model = raw.get('model', '')
        if not isinstance(key, str) or not 8 <= len(key) <= 512 or any(c.isspace() for c in key):
            raise ValueError('Enter a valid API key')
        if not isinstance(model, str) or not 1 <= len(model) <= 100 or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._' for c in model):
            raise ValueError('Enter a valid model identifier')
        estimate = number(raw.get('estimate_usd'), .001, 1000, 'Cost ceiling')
        cap = number(raw.get('daily_cap_usd'), estimate, 1000, 'Daily budget')
        with self.lock:
            if any(j['request']['provider'] == 'tripo' and j['status'] in ('queued', 'running') for j in self.list_jobs()):
                raise ValueError('Wait for existing Tripo jobs before changing connection settings')
            # Session-only credentials: never persist, log, or return the key.
            os.environ.update(TRIPO_API_KEY=key, TRIPO_MODEL=model, TRIPO_ESTIMATE_USD=str(estimate), LH3D_DAILY_CAP_USD=str(cap))
        return {'configured': True, 'model': model, 'estimate_usd': estimate, 'daily_cap_usd': cap,
                'note': 'Saved for this app session. No provider request was made.'}

    def tripo_balance(self):
        key = os.getenv('TRIPO_API_KEY')
        if not key:
            raise ValueError('Connect Tripo for this session first')
        request = urllib.request.Request('https://openapi.tripo3d.ai/v3/account/balance',
                                         headers={'Authorization': 'Bearer ' + key})
        try:
            with urllib.request.urlopen(request, timeout=15) as response:
                value = json.loads(response.read(64_000))
            if value.get('code') != 0 or not isinstance(value.get('data'), dict):
                raise ValueError('Tripo rejected the balance query')
            data = value['data']
            return {'available_credits': number(data.get('balance'), 0, 1e12, 'Balance'),
                    'frozen_credits': number(data.get('frozen', 0), 0, 1e12, 'Frozen credits'),
                    'note': 'Read-only API balance check. No generation was submitted.'}
        except (urllib.error.URLError, UnicodeError, json.JSONDecodeError) as exc:
            raise ValueError('Tripo balance could not be checked; verify the API key and connection') from exc

    def estimate(self, raw):
        r = validate(raw)
        cost = None if r["provider"] == "tripo" else 0
        if r["provider"] == "tripo" and os.getenv("TRIPO_ESTIMATE_USD"):
            cost = number(float(os.environ["TRIPO_ESTIMATE_USD"]), .001, 1000, "Configured Tripo estimate")
        return {"provider": r["provider"], "cost_usd": cost, "estimate_source": "user-configured price ceiling" if r["provider"] == "tripo" else "local",
                "paid": r["provider"] == "tripo", "ready": next(p["ready"] for p in self.capabilities() if p["id"] == r["provider"]),
                "request": r, "note": "No generation or paid network calls made by estimate."}

    def submit(self, raw):
        request = validate(raw)
        estimate = self.estimate(request)
        if not estimate["ready"]:
            raise ValueError("Provider is not configured. Open Connections for setup.")
        job_id = uuid.uuid4().hex
        if request["provider"] == "tripo":
            approved = raw.get("approved_usd")
            if approved is None or number(approved, 0, 1000, "Approved cost") < estimate["cost_usd"]:
                raise ValueError("Approve the configured cost ceiling before a paid generation")
            cap = number(float(os.getenv("LH3D_DAILY_CAP_USD", "5")), 0, 1000, "Daily cap")
            day = time.strftime("%Y-%m-%d", time.gmtime())
            with self.connect() as db:
                db.execute("BEGIN IMMEDIATE")
                used = db.execute("SELECT COALESCE(SUM(amount),0) FROM spend WHERE day=?", (day,)).fetchone()[0]
                if used + estimate["cost_usd"] > cap:
                    raise ValueError("Daily cloud reservation cap reached (UTC day)")
                db.execute("INSERT INTO spend VALUES (?,?,?)", (job_id, day, estimate["cost_usd"]))
        folder = self.state / job_id
        folder.mkdir()
        image = raw.get("image_base64")
        if request["provider"] in ("trellis", "pixal3d"):
            try:
                if not isinstance(image, str) or len(image) > 12_000_000:
                    raise ValueError("Upload a PNG or JPEG (max 8 MB)")
                data = base64.b64decode(image, validate=True)
                if not data.startswith(b"\x89PNG\r\n\x1a\n") and not data.startswith(b"\xff\xd8\xff"):
                    raise ValueError("Only PNG/JPEG inputs are supported")
                if request["provider"] == "pixal3d" and not data.startswith(b"\x89PNG"):
                    raise ValueError("Pixal3D SV requires a pre-matted RGBA PNG")
                (folder / "input.png").write_bytes(data)
            except Exception as exc:
                raise ValueError(str(exc)) from exc
        record = {"schema_version": 1, "id": job_id, "name": request["prompt"][:60] or request["recipe"].title(),
                  "request": request, "status": "queued", "stage": "Queued", "created": time.time(),
                  "parent_id": None, "review": None, "operations": [], "cost": estimate,
                  "input_sha256": hashlib.sha256((folder / "input.png").read_bytes()).hexdigest() if (folder / "input.png").exists() else None}
        self.save(record)
        self.pending.put(job_id)
        return record

    def edit(self, job_id, raw):
        parent = self.get(job_id)
        if parent["status"] != "succeeded":
            raise ValueError("Only completed assets can be edited")
        op = raw.get("operation")
        if op not in ("material", "decimate", "normalize"):
            raise ValueError("Operation must be material, decimate or normalize")
        if not find_blender():
            raise ValueError("Blender is not configured")
        params = validate({**parent["request"], **{k: raw[k] for k in ("color", "roughness", "metallic") if k in raw}, "provider": "blender"})
        params["ratio"] = number(raw.get("ratio", .5), .0001, 1, "Decimation ratio")
        params["height"] = number(raw.get("height", 1), .01, 100, "Height in metres")
        object_id = raw.get('object_id')
        slot = raw.get('material_slot')
        if object_id is not None:
            inventory = parent.get('object_inventory', [])
            target = next((o for o in inventory if o['id'] == object_id), None)
            if target is None:
                raise ValueError('Choose an object ID from this asset inventory')
            if op == 'normalize':
                raise ValueError('Scale and base pivot operate on the complete asset')
            params['object_id'] = object_id
            if slot is not None:
                slot = number(slot, 0, max(len(target['materials']) - 1, 0), 'Material slot', True)
                if op != 'material' or not target['materials']:
                    raise ValueError('Material slot requires an existing material on the selected object')
                params['material_slot'] = slot
        elif slot is not None:
            raise ValueError('Choose one object before selecting a material slot')
        child = {**parent, "id": uuid.uuid4().hex, "parent_id": parent["id"], "status": "queued", "stage": "Queued for Blender",
                 "created": time.time(), "review": None, "operations": parent["operations"] + [{"operation": op, "params": params, "script_version": "0.1.0"}],
                 "edit": {"operation": op, "params": params}, "cost": {"cost_usd": 0, "paid": False}}
        for key in ("metrics", "error", "elapsed", "remote_task_id", "finished", "blender_version", "artifacts"):
            child.pop(key, None)
        self.save(child)
        self.pending.put(child["id"])
        return child

    def retopologize(self, job_id, raw):
        parent = self.get(job_id)
        # A remote generation ID represents its original mesh, never a local edit.
        if parent['status'] != 'succeeded' or parent['request']['provider'] != 'tripo' or parent.get('parent_id') or not parent.get('remote_task_id'):
            raise ValueError('Select an original completed Tripo generation for cloud retopology')
        if not os.getenv('TRIPO_API_KEY'):
            raise ValueError('Connect Tripo for this session first')
        if not find_blender():
            raise ValueError('Blender is required to inspect the retopology result')
        request = validate(parent['request'])
        faces = number(raw.get('face_limit', 10000), 500, 20000, 'Target triangles', True)
        if number(raw.get('approved_usd', 0), 0, 1000, 'Approved cost') < .30:
            raise ValueError('Approve the $0.30 Tripo Smart Retopology cost before submitting')
        request.update(tripo_operation='retopology', input=parent['remote_task_id'], face_limit=faces)
        job_id = uuid.uuid4().hex
        day = time.strftime('%Y-%m-%d', time.gmtime())
        cap = number(float(os.getenv('LH3D_DAILY_CAP_USD', '5')), 0, 1000, 'Daily cap')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            used = db.execute('SELECT COALESCE(SUM(amount),0) FROM spend WHERE day=?', (day,)).fetchone()[0]
            if used + .30 > cap:
                raise ValueError('Daily cloud reservation cap reached (UTC day)')
            db.execute('INSERT INTO spend VALUES (?,?,?)', (job_id, day, .30))
        record = {'schema_version': 1, 'id': job_id, 'name': f"{parent['name'][:36]} · Tripo {faces:,}",
                  'request': request, 'status': 'queued', 'stage': 'Queued for Smart Retopology', 'created': time.time(),
                  'parent_id': parent['id'], 'review': None, 'operations': parent['operations'] + [{'operation': 'tripo_retopology', 'face_limit': faces, 'model': 'v2.0', 'bake': True}],
                  'input_sha256': parent.get('artifacts', {}).get('asset.glb', {}).get('sha256'),
                  'cost': {'cost_usd': .30, 'paid': True, 'estimate_source': 'https://developers.tripo3d.ai/en/pricing', 'rate_checked': '2026-10-03'}}
        self.save(record)
        self.pending.put(job_id)
        return record

    def import_asset(self, raw, lineage=None):
        if not find_blender():
            raise ValueError('Install Blender before importing an asset')
        encoded = raw.get('glb_base64')
        if not isinstance(encoded, str) or len(encoded) > (MAX_GLB_BYTES + 2) // 3 * 4:
            raise ValueError('Choose a self-contained GLB under 100 MB')
        try:
            data = base64.b64decode(encoded, validate=True)
        except ValueError as exc:
            raise ValueError('Invalid GLB encoding') from exc
        metadata = inspect_glb(data)
        request = validate({'provider': 'blender', 'prompt': raw.get('name', 'Imported model'), 'data_class': raw.get('data_class', 'unclassified')})
        if not request['prompt']:
            raise ValueError('Give the imported asset a name')
        job_id = uuid.uuid5(uuid.NAMESPACE_URL, 'lighthaus:blender-export:'+lineage['command_id']).hex if lineage else uuid.uuid4().hex
        if lineage:
            try:
                existing = self.get(job_id)
            except ValueError:
                existing = None
            if existing:
                if existing.get('live_blender', {}).get('command_id') != lineage['command_id']:
                    raise ValueError('Live export identity collision')
                return existing
        folder = self.state / job_id
        folder.mkdir()
        (folder / 'input.glb').write_bytes(data)
        record = {'schema_version': 1, 'id': job_id, 'name': request['prompt'][:60], 'request': request,
                  'status': 'queued', 'stage': 'Queued for import', 'created': time.time(), 'parent_id': None,
                  'review': None, 'operations': [], 'cost': {'cost_usd': 0, 'paid': False},
                  'imported': {'format': 'glb', 'source': 'user import', **metadata},
                  'input_sha256': hashlib.sha256(data).hexdigest()}
        if lineage:
            record['live_blender'] = lineage
            origins = lineage.get('source_job_ids', [])
            record['parent_id'] = origins[0] if len(origins) == 1 else None
        self.save(record)
        self.pending.put(job_id)
        return record

    def review(self, job_id, verdict, notes=""):
        if verdict not in ("approved", "redo", "replace") or not isinstance(notes, str) or len(notes) > 4000:
            raise ValueError("Invalid review")
        with self.lock:
            record = self.get(job_id)
            if record["status"] != "succeeded":
                raise ValueError("Review requires a completed asset")
            record["review"] = {"verdict": verdict, "notes": notes, "time": time.time()}
            self.save(record)
        return record

    def cancel(self, job_id):
        with self.lock:
            record = self.get(job_id)
            if record["request"]["provider"] == "tripo" and record["status"] == "running":
                raise ValueError("Cloud cancellation is not supported; billing may already be active")
            if record["status"] not in ("queued", "running"):
                return record
            record.update(status="cancelled", stage="Cancelled")
            self.save(record)
            if self.active_job == job_id and self.process:
                self.process.terminate()
        return record

    def run_process(self, args, folder, timeout=180, provider_env=None):
        # Cloud credentials are never passed to Blender or the local native engine.
        env = {k: v for k, v in os.environ.items() if not any(s in k.upper() for s in ("API_KEY", "TOKEN", "SECRET"))}
        if provider_env:
            env.update(provider_env)
        with (folder / "worker.log").open("a", encoding="utf-8") as log:
            with self.lock:
                if self.stop.is_set() or self.get(self.active_job)["status"] == "cancelled":
                    raise RuntimeError("Cancelled")
                self.process = subprocess.Popen(args, cwd=folder, stdout=log, stderr=subprocess.STDOUT, env=env,
                                               creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
            try:
                code = self.process.wait(timeout=timeout)
                if code:
                    raise RuntimeError("Worker failed; inspect the local worker.log for details")
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
                raise RuntimeError("Worker exceeded its time limit")
            finally:
                with self.lock:
                    self.process = None

    def blender(self, folder, spec):
        (folder / "blender-request.json").write_text(json.dumps(spec), encoding="utf-8")
        self.run_process([find_blender(), "--background", "--factory-startup", "--disable-autoexec", "--python-exit-code", "1",
                          "--python", str(ROOT / "blender/worker.py"), "--", str(folder / "blender-request.json")], folder)

    def work(self):
        while not self.stop.is_set():
            try:
                job_id = self.pending.get(timeout=.2)
            except queue.Empty:
                continue
            with self.lock:
                record = self.get(job_id)
                if record["status"] != "queued":
                    continue
                self.active_job = job_id
                record.update(status="running", stage="Editing in Blender" if "edit" in record else "Generating geometry")
                self.save(record)
            folder = self.state / job_id
            started = time.monotonic()
            try:
                if "edit" in record:
                    self.blender(folder, {"mode": "edit", "source": str(self.state / record["parent_id"] / "asset.glb"), **record["edit"]})
                elif 'imported' in record:
                    self.blender(folder, {'mode': 'inspect', 'source': str(folder / 'input.glb')})
                elif record["request"]["provider"] == "blender":
                    self.blender(folder, {"mode": "create", **record["request"]})
                elif record["request"]["provider"] in ("trellis", "pixal3d"):
                    record.update(stage="Verifying model files")
                    self.save(record)
                    record['native'] = verify_native(record['request']['provider'], record['request']['resolution'])
                    record.update(stage="Running native inference")
                    self.save(record)
                    self.run_process(local_command(record["request"]["provider"], folder / "input.png", folder / "raw.glb", record["request"]), folder, 3600)
                    record.update(stage="Inspecting and rendering in Blender")
                    self.save(record)
                    self.blender(folder, {"mode": "inspect", "source": str(folder / "raw.glb")})
                else:
                    # The helper saves its task id before polling; never resubmit automatically.
                    remote = self.tripo(folder, record)
                    record["remote_task_id"] = remote["task_id"]
                    record['provider_details'] = {k: remote.get(k) for k in ('model', 'credits_consumed', 'status', 'pricing_source')}
                    credits = remote.get('credits_consumed')
                    if isinstance(credits, (int, float)) and not isinstance(credits, bool) and math.isfinite(credits) and credits >= 0:
                        record['cost'].update(actual_credits=credits, usd_equivalent=credits / 100,
                                              rate_source='https://developers.tripo3d.ai/en/pricing', rate_checked='2026-10-03')
                        with self.connect() as db:
                            db.execute('UPDATE spend SET amount=? WHERE id=?', (credits / 100, record['id']))
                    self.blender(folder, {"mode": "inspect", "source": str(folder / "raw.glb")})
                metrics = json.loads((folder / "metrics.json").read_text(encoding="utf-8"))
                record.update(status="succeeded", stage="Ready for review", metrics=metrics["geometry"], blender_version=metrics["blender_version"])
                record['object_inventory'] = metrics.get('objects', [])
                if (folder / "remote.json").exists():
                    record["remote_task_id"] = json.loads((folder / "remote.json").read_text())["task_id"]
                record.update(elapsed=round(time.monotonic() - started, 2), finished=time.time())
                record['artifacts'] = {name: {'sha256': sha256(folder / name), 'size_bytes': (folder / name).stat().st_size}
                                       for name in ('asset.glb', 'asset.blend', 'preview.png') if (folder / name).is_file()}
            except Exception as exc:
                record.update(status="failed", stage="Generation failed", error=str(exc)[:500])
                if (folder / "remote.json").exists():
                    record["remote_task_id"] = json.loads((folder / "remote.json").read_text())["task_id"]
            with self.lock:
                if self.get(job_id)["status"] == "cancelled":
                    record.update(status="cancelled", stage="Cancelled")
                if self.stop.is_set() and record["status"] == "failed":
                    record.update(status="interrupted", stage="Interrupted on shutdown")
                self.save(record)
                if record["status"] == "succeeded":
                    (folder / "asset.provenance.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
                self.active_job = None

    def tripo(self, folder, record):
        # Only this adapter receives provider credentials. Logs use generic errors.
        if record["request"]["data_class"] not in ("synthetic", "licensed-reference"):
            raise ValueError("Cloud input rejected")
        (folder / "tripo-request.json").write_text(json.dumps(record["request"]), encoding="utf-8")
        try:
            self.run_process([os.getenv("LH3D_NODE", "node"), str(ROOT / "backend/tripo.mjs"), str(folder)], folder, 1800,
                             {"TRIPO_API_KEY": os.environ["TRIPO_API_KEY"]})
        except Exception as exc:
            error_file = folder / 'provider-error.json'
            if error_file.exists():
                error = json.loads(error_file.read_text())
                if error.get('no_submission') is True and not (folder / 'remote.json').exists():
                    with self.connect() as db:
                        db.execute('DELETE FROM spend WHERE id=?', (record['id'],))
                    record['cost']['reservation_released'] = True
                    raise RuntimeError(error['message']) from exc
            raise RuntimeError("Tripo worker failed; remote.json retains the task ID if submitted. Do not retry blindly.") from exc
        return json.loads((folder / "remote.json").read_text())

    def close(self):
        self.stop.set()
        with self.lock:
            if self.process:
                self.process.terminate()
        if self.worker:
            self.worker.join(timeout=5)
