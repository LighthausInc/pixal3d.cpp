import { TripoClient } from '@vastai/tripo-sdk';
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

export function credentialScopedFetch(implementation=fetch) {
  return (url,options={})=>{
    const parsed=new URL(url);
    if(parsed.protocol!=='https:')throw new Error('HTTPS is required');
    const headers=new Headers(options.headers);
    if(parsed.origin!=='https://openapi.tripo3d.ai')headers.delete('Authorization');
    return implementation(url,{...options,headers});
  };
}

export async function generateTripo(request, folder, client) {
  if (!['synthetic','licensed-reference'].includes(request.data_class)) throw new Error('Cloud classification rejected');
  const retopo = request.tripo_operation === 'retopology';
  if (retopo && (!request.input || !Number.isInteger(request.face_limit) || request.face_limit < 500 || request.face_limit > 20000)) throw new Error('Invalid retopology target');
  const taskId = retopo
    ? await client.decimateMesh({input:request.input, model:'v2.0', face_limit:request.face_limit, quad:false, bake:true})
    : await client.textToModel({prompt:request.prompt, model:process.env.TRIPO_MODEL, texture:true, pbr:true, texture_quality:'standard', model_seed:request.seed});
  if (typeof taskId !== 'string' || !taskId) throw new Error('Missing remote task ID');
  await writeFile(path.join(folder,'remote.json'), JSON.stringify({task_id:taskId, provider:'tripo'}));
  const task = await client.waitForTask(taskId, {pollingIntervalMs:3000, timeoutMs:1_500_000});
  await writeFile(path.join(folder,'remote.json'), JSON.stringify({task_id:taskId, provider:'tripo', model:retopo?'v2.0':process.env.TRIPO_MODEL,
    operation:retopo?'retopology':'generation',
    status:task.status, credits_consumed:task.credits_consumed??null, pricing_source:'https://developers.tripo3d.ai/en/pricing'}));
  const download = await client.downloadModel(task);
  if (!download?.data) throw new Error('No model output');
  const buffer = Buffer.from(download.data);
  if (buffer.subarray(0,4).toString() !== 'glTF') throw new Error('Provider returned a non-GLB asset');
  await writeFile(path.join(folder,'raw.glb'),buffer);
  return {task_id:taskId};
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const folder = process.argv[2];
  try {
    const request = JSON.parse(await readFile(path.join(folder,'tripo-request.json'),'utf8'));
    if (!process.env.TRIPO_MODEL) throw new Error('Model not configured');
    // Submission retries can duplicate billing; disable them. Polling is read-only.
    const client = new TripoClient({baseUrl:'https://openapi.tripo3d.ai/v3',retries:0,fetch:credentialScopedFetch()});
    const balance = await client.getBalance();
    await writeFile(path.join(folder,'billing-before.json'),JSON.stringify(balance));
    if(Number(balance.balance)<(request.tripo_operation==='retopology'?30:20)){
      await writeFile(path.join(folder,'provider-error.json'),JSON.stringify({code:2010,no_submission:true,message:'Tripo API credits are insufficient. Top up API credits in the Tripo console.'}));
      throw new Error('Insufficient API credits');
    }
    await generateTripo(request,folder,client);
  } catch (error) {
    // A definitive API rejection before task creation can release the local reservation.
    if(error?.name==='TripoAPIError' && [1000,1001,2002,2008,2010,2015].includes(error.code)){
      let submitted=false;try{await readFile(path.join(folder,'remote.json'));submitted=true;}catch{}
      if(!submitted)await writeFile(path.join(folder,'provider-error.json'),JSON.stringify({code:error.code,no_submission:true,
        message:error.code===2010?'Tripo API credits are insufficient. Top up API credits in the Tripo console.':'Tripo rejected the request before creating a task (code '+error.code+').'}));
    }
    // Expose only structured error codes, never request headers, URLs or credentials.
    process.stderr.write('Tripo generation failed. '+JSON.stringify({name:error?.name,code:error?.code,status:error?.status})+'\n');
    process.exitCode = 1;
  }
}
