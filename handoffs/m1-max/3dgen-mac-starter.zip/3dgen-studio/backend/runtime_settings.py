"""Load user-owned native runtime paths; environment values take precedence."""
import json
import os
from pathlib import Path
import subprocess
import sys


def settings_path():
    if os.getenv('LH3D_RUNTIME_CONFIG'):return Path(os.environ['LH3D_RUNTIME_CONFIG']).expanduser()
    base=Path(os.getenv('LOCALAPPDATA',str(Path.home())))/'Lighthaus3DGen' if os.name=='nt' else Path.home()/'Library/Application Support/Lighthaus3DGen'
    return base/'runtime.json'


def load_runtime():
    path=settings_path()
    if path.is_file():
        value=json.loads(path.read_text(encoding='utf-8'))
        for key in ('TRELLIS_BIN','TRELLIS_MODELS','PIXAL3D_BIN','PIXAL3D_MODELS','BLENDER_BIN','LH3D_NODE'):
            item=value.get(key)
            if item is not None:
                if not isinstance(item,str) or not item or '\x00' in item:raise ValueError('Invalid runtime path: '+key)
                os.environ.setdefault(key,item)
    if sys.platform=='darwin' and 'TRELLIS_FA_FAST' not in os.environ:
        result=subprocess.run(['/usr/sbin/sysctl','-n','machdep.cpu.brand_string'],capture_output=True,text=True,check=True)
        if 'Apple M1' in result.stdout:os.environ['TRELLIS_FA_FAST']='1'
