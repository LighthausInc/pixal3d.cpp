"""Explicitly launched, authenticated loopback development/desktop service."""
import argparse
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import os
from pathlib import Path
import secrets
import signal
import threading
from urllib.parse import unquote, urlsplit
from core import ROOT, Studio
from blender_bridge import BlenderBridge
from runtime_settings import load_runtime

def create_server(studio, token, port=0):
    bridge = BlenderBridge(studio)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def reply(self, data, code=200, mime="application/json"):
            payload = data if isinstance(data, bytes) else json.dumps(data).encode()
            self.send_response(code)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob: data:; connect-src 'self' blob:; worker-src 'self' blob:; object-src 'none'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(payload)

        def check(self, authenticated=False):
            port = self.server.server_address[1]
            if self.headers.get("Host") not in (f"127.0.0.1:{port}", f"localhost:{port}"):
                self.reply({"error":"Invalid Host"}, 403)
                return False
            origin = self.headers.get("Origin")
            if origin is not None and origin not in (f"http://127.0.0.1:{port}", f"http://localhost:{port}"):
                self.reply({"error":"Origin rejected"}, 403)
                return False
            if authenticated and not hmac.compare_digest(self.headers.get("Authorization", ""), "Bearer " + token):
                self.reply({"error":"Authentication required"}, 401)
                return False
            return True

        def do_GET(self):
            path = unquote(urlsplit(self.path).path)
            if not self.check(path.startswith(("/api/", "/assets/"))):
                return
            try:
                if path == "/api/providers":
                    return self.reply(studio.capabilities())
                if path == '/api/blender':
                    return self.reply(bridge.status())
                if path == '/api/blender/addon':
                    return self.reply((ROOT/'blender/studio_link.py').read_bytes(), mime='text/x-python')
                if path == "/api/jobs":
                    return self.reply(studio.list_jobs())
                if path.startswith("/api/jobs/"):
                    return self.reply(studio.get(path.split("/")[-1]))
                if path.startswith("/assets/"):
                    _,_,job_id,name = path.split("/")
                    studio.get(job_id)
                    if name not in ("asset.glb", "asset.blend", "preview.png", "asset.provenance.json", "manifest.json"):
                        raise ValueError("Unsupported asset file")
                    file = studio.state / job_id / name
                elif path.startswith("/vendor/three/"):
                    base = ROOT / "node_modules/three"
                    file = (base / path.removeprefix("/vendor/three/")).resolve()
                    if not file.is_relative_to(base.resolve()):
                        raise ValueError("Invalid static path")
                else:
                    base = ROOT / "ui"
                    file = (base / (path.lstrip("/") or "index.html")).resolve()
                    if not file.is_relative_to(base.resolve()):
                        raise ValueError("Invalid static path")
                mime = "text/javascript" if file.suffix in (".js", ".mjs") else mimetypes.guess_type(file.name)[0] or "application/octet-stream"
                content = file.read_bytes()
                if path.startswith('/vendor/three/') and file.suffix == '.js':
                    content = content.replace(b"from 'three'", b"from '/vendor/three/build/three.module.js'")
                return self.reply(content, mime=mime)
            except (ValueError, FileNotFoundError):
                self.reply({"error":"Not found"},404)

        def do_POST(self):
            if not self.check(True):
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                path = urlsplit(self.path).path
                if length <= 0 or length > (134_000_000 if path == '/api/import' else 12_000_000):
                    return self.reply({"error":"Request size limit exceeded"}, 413)
                if self.headers.get("Content-Type", "").split(";")[0] != "application/json":
                    return self.reply({"error":"Use application/json"},415)
                raw = json.loads(self.rfile.read(length))
                if not isinstance(raw, dict):
                    raise ValueError("Request must be an object")
                path = urlsplit(self.path).path
                if path.startswith('/api/blender/'):
                    action = path.removeprefix('/api/blender/')
                    handlers = {'connect': bridge.connect, 'disconnect': bridge.disconnect, 'poll': bridge.poll, 'complete': bridge.complete, 'command': bridge.enqueue}
                    if action not in handlers:
                        raise ValueError('Unknown Blender bridge endpoint')
                    return self.reply(handlers[action](raw))
                if path == '/api/settings/tripo':
                    return self.reply(studio.configure_tripo(raw))
                if path == '/api/import':
                    return self.reply(studio.import_asset(raw),202)
                if path == '/api/tripo/balance':
                    return self.reply(studio.tripo_balance())
                if path == "/api/estimate":
                    return self.reply(studio.estimate(raw))
                if path == "/api/generate":
                    return self.reply(studio.submit(raw),202)
                if path == "/api/shutdown":
                    self.reply({"status":"shutting_down"})
                    threading.Thread(target=self.server.shutdown,daemon=True).start()
                    return
                if path.startswith("/api/jobs/"):
                    _,_,_,job_id,operation = path.split("/")
                    if operation == "edit":
                        return self.reply(studio.edit(job_id,raw),202)
                    if operation == 'retopology':
                        return self.reply(studio.retopologize(job_id,raw),202)
                    if operation == "review":
                        return self.reply(studio.review(job_id,raw.get("verdict"),raw.get("notes","")))
                    if operation == "cancel":
                        return self.reply(studio.cancel(job_id))
                self.reply({"error":"Unknown endpoint"},404)
            except (ValueError, TypeError, KeyError, RecursionError) as exc:
                self.reply({"error":str(exc)[:300]},400)

    server = ThreadingHTTPServer(("127.0.0.1",port), Handler)
    server.daemon_threads = True
    return server

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--state")
    args = parser.parse_args()
    load_runtime()
    studio = Studio(args.state)
    token = os.getenv("LH3D_TOKEN") or secrets.token_urlsafe(32)
    server = create_server(studio,token,args.port)
    url = f"http://127.0.0.1:{server.server_address[1]}"
    session = studio.state / "session.json"
    session.write_text(json.dumps({"url":url,"token":token}),encoding="utf-8")
    try:
        session.chmod(0o600)
    except OSError:
        pass
    print(json.dumps({"url":url,"session_file":str(session)}),flush=True)
    def stop(*unused):
        threading.Thread(target=server.shutdown,daemon=True).start()
    signal.signal(signal.SIGINT,stop)
    signal.signal(signal.SIGTERM,stop)
    try:
        server.serve_forever()
    finally:
        studio.close()
        server.server_close()
        if session.exists() and json.loads(session.read_text())["token"] == token:
            session.unlink()

if __name__ == "__main__":
    main()
