"""Authenticated service-side command ledger for the opt-in Blender add-on.

Commands are claimed once. Lost acknowledgements stay uncertain rather than
replaying scene mutations. The add-on never exposes a listening socket.
"""
import base64
import hashlib
import json
import math
from pathlib import Path
import re
import threading
import time
from assets import inspect_glb


def identifier(value):
    if not isinstance(value, str) or not re.fullmatch('[a-f0-9]{32}', value):
        raise ValueError('Expected a 32-character object or command ID')
    return value


def scalar(value, low, high):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not low <= value <= high:
        raise ValueError(f'Expected a finite number between {low} and {high}')
    return float(value)


def vector(value, low, high):
    if not isinstance(value, list) or len(value) != 3:
        raise ValueError('Expected a three-component vector')
    return [scalar(v, low, high) for v in value]


class BlenderBridge:
    def __init__(self, studio):
        self.studio = studio
        self.lock = threading.RLock()
        self.peer = None
        self.last_seen = 0
        self.snapshot = None
        with studio.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS blender_commands (id TEXT PRIMARY KEY, record TEXT NOT NULL)')
            for row in db.execute('SELECT record FROM blender_commands').fetchall():
                record = json.loads(row[0])
                if record['status'] in ('queued', 'executing'):
                    record.update(status='uncertain' if record['status'] == 'executing' else 'cancelled',
                                  error='Studio restarted; inspect Blender before issuing a new command')
                    db.execute('UPDATE blender_commands SET record=? WHERE id=?', (json.dumps(record), record['id']))

    def save(self, record):
        with self.studio.connect() as db:
            db.execute('INSERT OR REPLACE INTO blender_commands VALUES (?,?)', (record['id'], json.dumps(record)))

    def get(self, command_id):
        identifier(command_id)
        with self.studio.connect() as db:
            row = db.execute('SELECT record FROM blender_commands WHERE id=?', (command_id,)).fetchone()
        if row is None:
            raise ValueError('Blender command not found')
        return json.loads(row[0])

    def status(self):
        with self.lock, self.studio.connect() as db:
            recent = [json.loads(r[0]) for r in db.execute('SELECT record FROM blender_commands ORDER BY rowid DESC LIMIT 20')]
            return {'connected': bool(self.peer and time.monotonic() - self.last_seen < 15),
                    'peer': self.peer, 'snapshot': self.snapshot, 'commands': recent,
                    'session_file': str(self.studio.state / 'session.json')}

    def connect(self, raw):
        peer = identifier(raw.get('peer_id'))
        with self.lock:
            if self.peer and self.peer['id'] != peer and time.monotonic() - self.last_seen < 15:
                raise ValueError('Another Blender session is already connected')
            if self.peer and self.peer['id'] != peer:
                with self.studio.connect() as db:
                    for row in db.execute('SELECT record FROM blender_commands').fetchall():
                        record = json.loads(row[0])
                        if record['status'] in ('queued', 'executing'):
                            record.update(status='cancelled' if record['status']=='queued' else 'uncertain', error='Blender session changed; command was not replayed')
                            self.save(record)
            self.peer = {'id': peer, 'version': str(raw.get('version', 'unknown'))[:50]}
            self.last_seen = time.monotonic()
            self.snapshot = None
            return {'connected': True, 'peer_id': peer}

    def poll(self, raw):
        peer = identifier(raw.get('peer_id'))
        with self.lock:
            if not self.peer or self.peer['id'] != peer:
                raise ValueError('Reconnect this Blender session')
            self.last_seen = time.monotonic()
            with self.studio.connect() as db:
                records = [json.loads(r[0]) for r in db.execute('SELECT record FROM blender_commands ORDER BY rowid')]
            # Preserve sequential mutation ordering; uncertain work needs inspection.
            if any(r['peer_id']==peer and r['status'] in ('executing', 'uncertain') for r in records):
                return {'command': None}
            command = next((r for r in records if r['peer_id']==peer and r['status']=='queued'), None)
            if command:
                command.update(status='executing', claimed=time.time())
                self.save(command)
            return {'command': command}

    def disconnect(self, raw):
        peer = identifier(raw.get('peer_id'))
        with self.lock:
            if not self.peer or self.peer['id'] != peer:
                raise ValueError('This Blender session is not connected')
            with self.studio.connect() as db:
                records = [json.loads(r[0]) for r in db.execute('SELECT record FROM blender_commands')]
            for record in records:
                if record['peer_id'] == peer and record['status'] in ('queued', 'executing'):
                    record.update(status='cancelled' if record['status']=='queued' else 'uncertain', error='Blender disconnected; inspect scene before a new command')
                    self.save(record)
            self.peer = None
            self.last_seen = 0
            return {'connected': False}

    def enqueue(self, raw):
        command_id = identifier(raw.get('command_id'))
        op = raw.get('operation')
        args = raw.get('args', {})
        if not isinstance(args, dict):
            raise ValueError('Blender arguments must be an object')
        if op not in ('inspect', 'import_asset', 'create_primitive', 'transform', 'material', 'decimate', 'export_asset'):
            raise ValueError('Unsupported Blender operation')
        normalized = {}
        if op == 'import_asset':
            job = self.studio.get(identifier(args.get('job_id')))
            if job['status'] != 'succeeded':
                raise ValueError('Only completed assets can be sent to Blender')
            source = self.studio.state / job['id'] / 'asset.glb'
            inspect_glb(source.read_bytes())
            normalized = {'job_id': job['id'], 'source': str(source), 'name': job['name'][:80]}
        if op == 'create_primitive':
            shape = args.get('shape', 'cube')
            name = args.get('name', 'Studio object')
            if shape not in ('cube', 'sphere', 'cylinder') or not isinstance(name, str) or not 1 <= len(name) <= 80:
                raise ValueError('Choose a named cube, sphere or cylinder')
            normalized = {'shape': shape, 'name': name, 'location': vector(args.get('location', [0,0,0]), -1000, 1000)}
        if op in ('transform', 'material', 'decimate', 'export_asset'):
            ids = args.get('object_ids')
            if not isinstance(ids, list) or not 1 <= len(ids) <= 100 or len(set(ids)) != len(ids):
                raise ValueError('Choose 1–100 distinct Blender object IDs')
            normalized['object_ids'] = [identifier(i) for i in ids]
        if op == 'transform':
            normalized.update(location=vector(args.get('location', [0,0,0]), -1000, 1000),
                              rotation=vector(args.get('rotation', [0,0,0]), -3600, 3600),
                              scale=vector(args.get('scale', [1,1,1]), .0001, 1000))
        if op == 'material':
            color = args.get('color', '#c78dff')
            slot = args.get('material_slot', 0)
            if not isinstance(color, str) or not re.fullmatch('#[0-9a-fA-F]{6}', color) or type(slot) is not int or not 0 <= slot <= 100:
                raise ValueError('Choose a hex color and material slot')
            normalized.update(color=color, material_slot=slot, roughness=scalar(args.get('roughness', .32), 0, 1), metallic=scalar(args.get('metallic', .2), 0, 1))
        if op == 'decimate':
            normalized['ratio'] = scalar(args.get('ratio', .5), .0001, 1)
        if op == 'export_asset':
            dest = self.studio.state / 'live-exports'
            dest.mkdir(exist_ok=True)
            normalized['destination'] = str(dest / (command_id + '.glb'))
        fingerprint = hashlib.sha256(json.dumps({'operation': op, 'args': normalized}, sort_keys=True).encode()).hexdigest()
        with self.lock:
            try:
                previous = self.get(command_id)
            except ValueError:
                previous = None
            if previous:
                if previous['fingerprint'] != fingerprint:
                    raise ValueError('Command ID was already used for different arguments')
                return previous
            if not self.peer or time.monotonic() - self.last_seen >= 15:
                raise ValueError('Connect Blender using the Studio Link add-on first')
            record = {'id': command_id, 'peer_id': self.peer['id'], 'operation': op, 'args': normalized,
                      'fingerprint': fingerprint, 'status': 'queued', 'created': time.time()}
            self.save(record)
            return record

    def complete(self, raw):
        with self.lock:
            record = self.get(raw.get('command_id'))
            if raw.get('peer_id') != record['peer_id'] or not self.peer or raw['peer_id'] != self.peer['id']:
                raise ValueError('Command belongs to a different Blender session')
            if record['status'] in ('succeeded', 'failed'):
                return record  # Acknowledgement retries never repeat exports or edits.
            if record['status'] != 'executing':
                raise ValueError('Command is not awaiting a result')
            result = raw.get('result', {})
            if not isinstance(result, dict) or len(json.dumps(result)) > 2_000_000:
                raise ValueError('Invalid Blender result')
            error = raw.get('error')
            if error:
                record.update(status='failed', error=str(error)[:300])
            else:
                try:
                    if record['operation'] == 'export_asset':
                        data = Path(record['args']['destination']).read_bytes()
                        origins = result.get('source_job_ids', [])
                        valid_origins = []
                        for origin in origins[:100]:
                            try: valid_origins.append(self.studio.get(identifier(origin))['id'])
                            except ValueError: pass
                        job = self.studio.import_asset({'name': 'Blender live edit', 'glb_base64': base64.b64encode(data).decode(), 'data_class': 'unclassified'},
                            lineage={'peer_id': record['peer_id'], 'command_id': record['id'], 'source_job_ids': valid_origins})
                        result['job_id'] = job['id']
                    record.update(status='succeeded', result=result)
                except (OSError, ValueError) as exc:
                    record.update(status='failed', error='Live export could not be imported: '+str(exc)[:230])
                if isinstance(result.get('snapshot'), dict):
                    self.snapshot = result['snapshot']
            record['finished'] = time.time()
            self.last_seen = time.monotonic()
            self.save(record)
            return record
