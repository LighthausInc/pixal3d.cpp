import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { CallToolRequestSchema, ListToolsRequestSchema } from '@modelcontextprotocol/sdk/types.js';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';

const state = process.env.LH3D_STATE || (process.platform==='win32' ? path.join(process.env.LOCALAPPDATA || os.homedir(),'Lighthaus3DGen') : path.join(os.homedir(),'Library/Application Support/Lighthaus3DGen'));
const server = new Server({name:'lighthaus-3dgen',version:'0.1.0'},{capabilities:{tools:{}}});
const object = properties => ({type:'object',properties,additionalProperties:false});
const request = {provider:{type:'string',enum:['blender','trellis','pixal3d','tripo']},prompt:{type:'string'},recipe:{type:'string',enum:['vessel','robot','pedestal']},data_class:{type:'string',enum:['synthetic','licensed-reference','clinical','unclassified']},seed:{type:'integer'},resolution:{type:'integer',enum:[512,1024,1536]},image_base64:{type:'string'},approved_usd:{type:'number'}};
const tools = [
  {name:'blender_live_status',description:'Inspect the connected live Blender session, scene object IDs, material slots, transforms and recent command results. Blender edits use its main-thread app timer.',inputSchema:object({})},
  {name:'blender_live_command',description:'Queue an allow-listed live Blender operation. Generate one UUID without dashes for command_id; reuse that ID and identical arguments on transport retry. Never retry uncertain work under a new ID without inspecting Blender. Transform locations/scales are absolute local coordinates; rotations are XYZ degrees. Import accepts a completed Studio job_id; export returns a versioned Studio job. No arbitrary code or file paths.',inputSchema:{...object({command_id:{type:'string',pattern:'^[a-f0-9]{32}$'},operation:{type:'string',enum:['inspect','import_asset','create_primitive','transform','material','decimate','export_asset']},args:object({job_id:{type:'string'},object_ids:{type:'array',items:{type:'string'},minItems:1,maxItems:100},shape:{type:'string',enum:['cube','sphere','cylinder']},name:{type:'string',maxLength:80},location:{type:'array',items:{type:'number'},minItems:3,maxItems:3},rotation:{type:'array',items:{type:'number'},minItems:3,maxItems:3},scale:{type:'array',items:{type:'number'},minItems:3,maxItems:3},material_slot:{type:'integer',minimum:0},color:{type:'string',pattern:'^#[0-9a-fA-F]{6}$'},roughness:{type:'number',minimum:0,maximum:1},metallic:{type:'number',minimum:0,maximum:1},ratio:{type:'number',minimum:.0001,maximum:1}})}),required:['command_id','operation']}},
  {name:'list_providers',description:'List available providers and configuration readiness.',inputSchema:object({})},
  {name:'estimate_cost',description:'Validate a request and estimate its cost without network calls.',inputSchema:object(request)},
  {name:'generate_asset',description:'Queue an asset. Tripo requires explicit approved_usd and permitted data classification. Never invent user approval.',inputSchema:object(request)},
  {name:'import_asset',description:'Import a self-contained GLB for local Blender inspection, object inventory and versioned refinement. No cloud call.',inputSchema:{...object({glb_base64:{type:'string'},name:{type:'string'},data_class:{type:'string',enum:['synthetic','licensed-reference','clinical','unclassified']}}),required:['glb_base64','name']}},
  {name:'list_jobs',description:'List persistent jobs and asset versions.',inputSchema:object({})},
  {name:'tripo_retopology',description:'Run paid Smart Retopology v2.0 on an original completed Tripo generation. Rebuilds mesh and bakes textures; triangle target 500–20000. Requires explicit user approval of $0.30. Never invent approval.',inputSchema:{...object({job_id:{type:'string'},face_limit:{type:'integer',minimum:500,maximum:20000},approved_usd:{type:'number',minimum:.30}}),required:['job_id','approved_usd']}},
  {name:'get_job',description:'Get job state, geometry metrics, review and provenance. Asset files are in the local state directory.',inputSchema:{...object({job_id:{type:'string'}}),required:['job_id']}},
  {name:'blender_op',description:'Create a version using an allow-listed Blender material, decimate, or normalize operation. Use object_id from get_job object_inventory to target one object; material_slot targets one slot. Omit object_id for all objects. No arbitrary code.',inputSchema:{...object({job_id:{type:'string'},operation:{type:'string',enum:['material','decimate','normalize']},object_id:{type:'string'},material_slot:{type:'integer',minimum:0},color:{type:'string'},roughness:{type:'number'},metallic:{type:'number'},ratio:{type:'number'},height:{type:'number'}}),required:['job_id','operation']}},
  {name:'submit_for_review',description:'Record a review verdict and notes on a completed asset.',inputSchema:{...object({job_id:{type:'string'},verdict:{type:'string',enum:['approved','redo','replace']},notes:{type:'string'}}),required:['job_id','verdict']}}
];
server.setRequestHandler(ListToolsRequestSchema,async()=>({tools}));
server.setRequestHandler(CallToolRequestSchema,async({params})=>{
  try {
    const session = JSON.parse(await readFile(path.join(state,'session.json'),'utf8'));
    const base = new URL(session.url);
    if(base.protocol!=='http:' || base.hostname!=='127.0.0.1') throw new Error('Invalid local session');
    const a = params.arguments || {};
    const id = encodeURIComponent(a.job_id || '');
    const routes = {list_providers:['GET','/api/providers'],estimate_cost:['POST','/api/estimate'],generate_asset:['POST','/api/generate'],import_asset:['POST','/api/import'],list_jobs:['GET','/api/jobs'],get_job:['GET',`/api/jobs/${id}`],blender_op:['POST',`/api/jobs/${id}/edit`],submit_for_review:['POST',`/api/jobs/${id}/review`]};
    routes.tripo_retopology=['POST',`/api/jobs/${id}/retopology`];
    routes.blender_live_status=['GET','/api/blender'];
    routes.blender_live_command=['POST','/api/blender/command'];
    if(!routes[params.name]) throw new Error('Unknown tool');
    const [method,route] = routes[params.name];
    const response = await fetch(new URL(route,base),{method,headers:{Authorization:`Bearer ${session.token}`,'Content-Type':'application/json'},body:method==='POST'?JSON.stringify(a):undefined,signal:AbortSignal.timeout(15000)});
    const data = await response.json();
    return {content:[{type:'text',text:JSON.stringify(data)}],isError:!response.ok};
  } catch(error) {
    return {content:[{type:'text',text:`Studio connection failed: ${error.code==='ENOENT'?'Start the Studio application first.':error.message}`}],isError:true};
  }
});
await server.connect(new StdioServerTransport());
