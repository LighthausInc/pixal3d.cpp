"""Bounded, self-contained GLB import validation before a Blender worker sees a file."""
import json
import struct

MAX_GLB_BYTES = 100_000_000

def inspect_glb(data):
    if not isinstance(data, bytes) or not 20 <= len(data) <= MAX_GLB_BYTES:
        raise ValueError('GLB must be between 20 bytes and 100 MB')
    magic, version, length = struct.unpack_from('<4sII', data)
    if magic != b'glTF' or version != 2 or length != len(data):
        raise ValueError('Invalid GLB 2.0 header or length')
    offset, document, chunks = 12, None, []
    while offset < length:
        if offset + 8 > length:
            raise ValueError('Truncated GLB chunk header')
        size, kind = struct.unpack_from('<II', data, offset)
        offset += 8
        if size % 4 or offset + size > length:
            raise ValueError('Invalid GLB chunk length')
        if not chunks and kind != 0x4E4F534A:
            raise ValueError('GLB JSON chunk must be first')
        if kind == 0x4E4F534A:
            if document is not None or size > 8_000_000:
                raise ValueError('Invalid or oversized GLB JSON chunk')
            try:
                document = json.loads(data[offset:offset + size].decode('utf-8'))
            except (UnicodeError, ValueError, RecursionError) as exc:
                raise ValueError('Invalid GLB JSON') from exc
        elif kind != 0x004E4942 or kind in chunks:
            raise ValueError('Unsupported or duplicate GLB chunk')
        chunks.append(kind)
        offset += size
    if not isinstance(document, dict) or not isinstance(document.get('asset'), dict) or document['asset'].get('version') != '2.0':
        raise ValueError('GLB asset version must be 2.0')
    if not isinstance(document.get('meshes'), list) or not document['meshes']:
        raise ValueError('GLB must contain mesh geometry')
    # Blender must not fetch a URL or open a path embedded in a supplied asset.
    stack = [(document, 0)]
    while stack:
        value, depth = stack.pop()
        if depth > 64:
            raise ValueError('GLB JSON nesting exceeds limit')
        if isinstance(value, dict):
            for key, child in value.items():
                if key == 'uri' and (not isinstance(child, str) or not child.startswith(('data:image/png;base64,', 'data:image/jpeg;base64,', 'data:image/webp;base64,', 'data:application/octet-stream;base64,', 'data:application/gltf-buffer;base64,'))):
                    raise ValueError('Only self-contained GLB files are supported; external resources are blocked')
                stack.append((child, depth + 1))
        elif isinstance(value, list):
            stack.extend((child, depth + 1) for child in value)
    return {'mesh_count': len(document['meshes']), 'generator': str(document.get('asset', {}).get('generator', 'unknown'))[:200]}
