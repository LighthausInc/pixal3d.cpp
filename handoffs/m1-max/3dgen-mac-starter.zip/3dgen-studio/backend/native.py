"""Verify pinned native model files before inference; keep identities in provenance."""
import hashlib
import json
import os
from pathlib import Path
import threading

_cache = {}
_lock = threading.Lock()

def sha256(path):
    path = Path(path)
    stat = path.stat()
    key = (str(path.resolve()), stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)
    with _lock:
        if key in _cache:
            return _cache[key]
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(chunk)
    value = digest.hexdigest()
    with _lock:
        _cache[key] = value
    return value

def verify_native(provider, resolution):
    prefix = provider.upper()
    binary = Path(os.environ[prefix + '_BIN']).resolve()
    directory = Path(os.environ[prefix + '_MODELS']).resolve()
    manifest_path = directory / 'manifest.json'
    if not manifest_path.is_file():
        raise ValueError('A pinned model manifest.json is required before local inference')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    if manifest.get('schema_version') != 1 or manifest.get('provider') != provider or not manifest.get('revision'):
        raise ValueError('Model manifest schema, provider or revision is invalid')
    entries = manifest.get('files', [])
    names = set()
    verified = []
    for entry in entries:
        name = entry.get('name', '')
        if not name or '/' in name or '\\' in name or ':' in name or name in ('.', '..') or name in names:
            raise ValueError('Model manifest contains an invalid or duplicate filename')
        names.add(name)
        # A 512-only installation does not need the separate 1024 flow weights.
        if provider == 'trellis' and resolution == 512 and name in ('shape_flow_1024.gguf', 'tex_flow_1024.gguf'):
            continue
        path = directory / name
        if path.resolve().parent != directory or not path.is_file():
            raise ValueError('Missing or out-of-directory model file: ' + name)
        expected = entry.get('sha256', '')
        if len(expected) != 64 or path.stat().st_size != entry.get('size_bytes') or sha256(path) != expected:
            raise ValueError('Model integrity verification failed: ' + name)
        verified.append({'name': name, 'sha256': expected, 'size_bytes': path.stat().st_size})
    if provider == 'trellis':
        required = {'dinov3.gguf', 'shape_dec.gguf', 'ss_dec.gguf', 'ss_flow.gguf', 'tex_dec.gguf', 'shape_flow_512.gguf', 'tex_flow_512.gguf'}
        if resolution > 512:
            required |= {'shape_flow_1024.gguf', 'tex_flow_1024.gguf'}
        if not required.issubset({entry['name'] for entry in verified}):
            raise ValueError('Model manifest does not cover all required TRELLIS weights')
    elif not verified:
        raise ValueError('Model manifest is empty')
    return {'engine': {'filename': binary.name, 'sha256': sha256(binary), 'version': manifest.get('engine_version', 'unspecified')},
            'models': {'id': manifest.get('id'), 'revision': manifest['revision'], 'source': manifest.get('source'),
                       'manifest_sha256': sha256(manifest_path), 'files': verified,
                       'license_status': manifest.get('license_status', 'not reviewed')},
            'settings': {'TRELLIS_FA_FAST': os.getenv('TRELLIS_FA_FAST', 'engine default')},
            'verification': 'File hashes match the local pinned manifest; manifest trust is established at installation.'}
