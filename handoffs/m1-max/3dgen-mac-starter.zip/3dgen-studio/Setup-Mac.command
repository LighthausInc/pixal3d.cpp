#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON="${LH3D_PYTHON:-$(command -v python3 || true)}"
if [[ -z "$PYTHON" ]]; then echo 'Install native arm64 Python 3.11+ first.'; exit 1; fi
caffeinate -i "$PYTHON" tools/setup-mac.py "$@"
