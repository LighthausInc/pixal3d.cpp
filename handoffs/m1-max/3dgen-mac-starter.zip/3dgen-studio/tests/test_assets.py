import base64
import hashlib
import json
import os
from pathlib import Path
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'backend'))
from assets import inspect_glb
from core import Studio

def glb(document):
    encoded = json.dumps(document).encode()
    encoded += b' ' * (-len(encoded) % 4)
    return struct.pack('<4sIIII', b'glTF', 2, 20 + len(encoded), len(encoded), 0x4E4F534A) + encoded

class AssetTests(unittest.TestCase):
    def test_external_resources_are_blocked_before_blender(self):
        for uri in ('https://example.org/private.png', '../private.png', 'file:///C:/secret', '//host/share'):
            data = glb({'asset': {'version': '2.0'}, 'meshes': [{}], 'images': [{'uri': uri}]})
            with self.assertRaisesRegex(ValueError, 'external'):
                inspect_glb(data)
    def test_bad_lengths_and_documents_fail_closed(self):
        valid = glb({'asset': {'version': '2.0'}, 'meshes': [{}]})
        for value in (valid[:-1], valid + b'junk', glb({'asset': [], 'meshes': [{}]}), glb({'asset': {'version': '2.0'}, 'meshes': []})):
            with self.assertRaises(ValueError): inspect_glb(value)
    def test_real_asset_import_records_identity_without_spawning(self):
        data = (Path(__file__).resolve().parents[1] / 'demo-history/06edbddf4805482fa15b0d4af446ea86/asset.glb').read_bytes()
        # Source-only archive contains the same demo fixture within the app.
        with tempfile.TemporaryDirectory() as temp, patch('core.find_blender', return_value='blender'):
            studio = Studio(temp, start_worker=False)
            job = studio.import_asset({'name': 'Imported robot', 'glb_base64': base64.b64encode(data).decode()})
            self.assertEqual(job['status'], 'queued')
            self.assertEqual(job['input_sha256'], hashlib.sha256(data).hexdigest())
            self.assertFalse(job['cost']['paid'])
            self.assertEqual((Path(temp) / job['id'] / 'input.glb').read_bytes(), data)
            studio.close()
    def test_unknown_object_and_material_slot_rejected(self):
        with tempfile.TemporaryDirectory() as temp, patch('core.find_blender', return_value='blender'):
            studio = Studio(temp, start_worker=False)
            parent={'id':'parent', 'status':'succeeded', 'request':{'provider':'blender'}, 'operations':[],
                    'object_inventory':[{'id':'head','name':'Head','materials':[{'slot':0,'name':'Brass'}]}]}
            studio.save(parent)
            for raw in ({'operation':'material','object_id':'missing'}, {'operation':'material','object_id':'head','material_slot':1}, {'operation':'material','material_slot':0}, {'operation':'normalize','object_id':'head'}):
                with self.assertRaises(ValueError): studio.edit('parent', raw)
            child=studio.edit('parent',{'operation':'material','object_id':'head','material_slot':0,'color':'#112233'})
            self.assertEqual(child['edit']['params']['object_id'],'head')
            self.assertEqual(child['parent_id'],'parent')
            studio.close()

if __name__ == '__main__': unittest.main()
