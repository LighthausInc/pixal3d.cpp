import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
test('MCP client discovers tools and calls shared authenticated service',async()=>{
  const python=process.env.LH3D_PYTHON;
  if(!python)throw Error('Set LH3D_PYTHON for MCP integration testing');
  const state=path.resolve(root,'../../work/mcp-test-state');
  const worker=spawn(python,['-u',path.join(root,'backend/server.py'),'--state',state],{windowsHide:true});
  try{
    await new Promise((resolve,reject)=>{worker.stdout.once('data',resolve);worker.once('error',reject);worker.once('exit',code=>reject(Error('Server exited '+code)));});
    const transport=new StdioClientTransport({command:process.execPath,args:[path.join(root,'backend/mcp.mjs')],env:{...process.env,LH3D_STATE:state},stderr:'pipe'});
    const client=new Client({name:'prototype-test',version:'1.0.0'});
    await client.connect(transport);
    const listing=await client.listTools();
    assert.equal(listing.tools.length,11);
    const live=await client.callTool({name:'blender_live_status',arguments:{}});
    assert.equal(live.isError,false);
    assert.equal(JSON.parse(live.content[0].text).connected,false);
    const invalidLive=await client.callTool({name:'blender_live_command',arguments:{command_id:'a'.repeat(32),operation:'python',args:{}}});
    assert.equal(invalidLive.isError,true);
    assert.ok(listing.tools.find(t=>t.name==='tripo_retopology').inputSchema.required.includes('approved_usd'));
    assert.ok(listing.tools.find(t=>t.name==='blender_op'));
    const result=await client.callTool({name:'estimate_cost',arguments:{provider:'blender',recipe:'vessel'}});
    assert.equal(result.isError,false);
    assert.equal(JSON.parse(result.content[0].text).cost_usd,0);
    const blocked=await client.callTool({name:'generate_asset',arguments:{provider:'tripo',prompt:'object',data_class:'clinical',approved_usd:100}});
    assert.equal(blocked.isError,true);
    assert.match(blocked.content[0].text,/classification|reference/);
    await client.close();
  }finally{worker.kill();}
});
