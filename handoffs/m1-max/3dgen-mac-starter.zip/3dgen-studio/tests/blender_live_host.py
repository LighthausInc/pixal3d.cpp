"""Disposable hidden GUI host: exercise the real Blender app timer, then quit."""
import importlib.util
import json
from pathlib import Path
import sys
import time
import bpy
config=json.loads(Path(sys.argv[sys.argv.index('--')+1]).read_text())
spec=importlib.util.spec_from_file_location('studio_link',config['addon'])
link=importlib.util.module_from_spec(spec)
spec.loader.exec_module(link)
link.register()
client=link.LinkClient(config['session_file'])
client.start()
deadline=time.monotonic()+240
def stop_when_finished():
    if Path(config['stop_file']).exists() or time.monotonic()>deadline:
        client.close()
        bpy.ops.wm.quit_blender()
        return None
    return .25
bpy.app.timers.register(stop_when_finished,first_interval=.25)
