import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js';
import path from 'node:path';
test('Real Blender demonstration GLB parses with the viewport loader',async()=>{
  const bytes=await readFile(path.resolve('demo-history/06edbddf4805482fa15b0d4af446ea86/asset.glb'));
  const buffer=bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength);
  const gltf=await new GLTFLoader().parseAsync(buffer,'');
  let meshes=0,triangles=0;
  gltf.scene.traverse(object=>{if(object.isMesh){meshes++;triangles+=(object.geometry.index?.count||object.geometry.attributes.position.count)/3;}});
  assert.equal(meshes,9);
  assert.equal(triangles,837);
});
