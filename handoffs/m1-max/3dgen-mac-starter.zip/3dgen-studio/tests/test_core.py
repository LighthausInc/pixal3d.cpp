import json
import io
import os
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
import urllib.error
import urllib.request
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"backend"))
from core import Studio, validate, local_command
from server import create_server

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.studio=Studio(self.temp.name,start_worker=False)
    def tearDown(self):
        self.studio.close()
        self.temp.cleanup()
    def test_clinical_and_unknown_cannot_reach_cloud(self):
        for tag in ("clinical","unclassified",None):
            with self.assertRaises(ValueError):
                validate({"provider":"tripo","prompt":"object","data_class":tag})
    def test_nan_and_boolean_parameters_rejected(self):
        for raw in ({"roughness":float('nan')},{"seed":True},{"resolution":700},{"color":"#bad<script>"}):
            with self.assertRaises(ValueError):validate(raw)
    def test_estimate_performs_no_paid_work(self):
        with patch('subprocess.run',side_effect=AssertionError('network worker called')):
            estimate=self.studio.estimate({"provider":"tripo","prompt":"a vessel","data_class":"synthetic"})
        self.assertTrue(estimate['paid'])
    def test_session_connection_does_not_call_provider_or_persist_key(self):
        with patch.dict(os.environ, {}, clear=False), patch('subprocess.Popen', side_effect=AssertionError('provider called')):
            result=self.studio.configure_tripo({'api_key':'private-test-key', 'model':'v3.1-20260211', 'estimate_usd':1, 'daily_cap_usd':5})
            self.assertTrue(result['configured'])
            self.assertNotIn('private-test-key', json.dumps(result)+json.dumps(self.studio.capabilities()))
            self.assertEqual(self.studio.list_jobs(), [])
            self.assertFalse(any(p.suffix == '.json' for p in Path(self.temp.name).rglob('*')))
    def test_api_balance_check_is_read_only_and_redacts_key(self):
        def reply(request, **kwargs):
            self.assertEqual(request.get_method(), 'GET')
            self.assertEqual(request.full_url, 'https://openapi.tripo3d.ai/v3/account/balance')
            return io.BytesIO(b'{"code":0,"data":{"balance":4980,"frozen":0}}')
        with patch.dict(os.environ, {'TRIPO_API_KEY':'private-balance-key'}), patch('core.urllib.request.urlopen', side_effect=reply):
            result=self.studio.tripo_balance()
        self.assertEqual(result['available_credits'],4980)
        self.assertNotIn('private-balance-key',json.dumps(result))
        self.assertEqual(self.studio.list_jobs(),[])
    def test_daily_spend_reservation_is_persistent(self):
        with patch.dict(os.environ,{"TRIPO_API_KEY":"test-secret","TRIPO_MODEL":"test-model","TRIPO_ESTIMATE_USD":".3","LH3D_DAILY_CAP_USD":".5"}):
            raw={"provider":"tripo","prompt":"a vessel","data_class":"synthetic"}
            with self.assertRaises(ValueError):self.studio.submit(raw)
            first=self.studio.submit({**raw,"approved_usd":.3})
            other=Studio(self.temp.name,start_worker=False)
            with self.assertRaises(ValueError):other.submit({**raw,"approved_usd":.3})
            self.assertNotIn('test-secret',json.dumps(first))
            other.close()
    def test_retopology_checks_source_approval_and_reserves_budget(self):
        parent = {'id':'cloud-original','name':'Aster','status':'succeeded','parent_id':None,
                  'request':validate({'provider':'tripo','data_class':'synthetic','prompt':'robot'}),
                  'remote_task_id':'remote-original','operations':[]}
        self.studio.save(parent)
        with patch.dict(os.environ, {'TRIPO_API_KEY':'test-key','LH3D_DAILY_CAP_USD':'.5'}), patch('core.find_blender', return_value='blender'):
            for raw in ({}, {'approved_usd':.3,'face_limit':20001}, {'approved_usd':.3,'face_limit':True}):
                with self.assertRaises(ValueError): self.studio.retopologize(parent['id'],raw)
            result = self.studio.retopologize(parent['id'], {'approved_usd':.3,'face_limit':10000})
            self.assertEqual(result['request']['input'],'remote-original')
            self.assertEqual(result['parent_id'],parent['id'])
            self.assertEqual(result['cost']['cost_usd'],.3)
            with self.assertRaisesRegex(ValueError,'cap'): self.studio.retopologize(parent['id'],{'approved_usd':.3})
            parent.update(parent_id='prior-local-source')
            self.studio.save(parent)
            with self.assertRaisesRegex(ValueError,'original'): self.studio.retopologize(parent['id'],{'approved_usd':.3})

    def test_review_updates_manifest_and_sidecar(self):
        record={"id":"abc","status":"succeeded","operations":[]}
        self.studio.save(record)
        self.studio.review('abc','approved','looks good')
        sidecar=json.loads((Path(self.temp.name)/'abc/asset.provenance.json').read_text())
        self.assertEqual(sidecar['review']['notes'],'looks good')
        self.assertEqual(Studio(self.temp.name,start_worker=False).get('abc')['review']['verdict'],'approved')
    def test_restart_marks_running_jobs_interrupted(self):
        self.studio.save({"id":"abc","status":"running"})
        other=Studio(self.temp.name)
        self.assertEqual(other.get('abc')['status'],'interrupted')
        other.close()
    def test_local_cli_uses_argument_list_no_shell_and_correct_fork_flags(self):
        binary=Path(self.temp.name)/'engine.exe';binary.touch()
        with patch.dict(os.environ,{"TRELLIS_BIN":str(binary),"TRELLIS_MODELS":self.temp.name,"PIXAL3D_BIN":str(binary),"PIXAL3D_MODELS":self.temp.name}):
            r=validate({"resolution":512})
            args=local_command('trellis','a b.png','out.glb',r)
            self.assertIn('a b.png',args)
            self.assertIn('--require-gpu',args)
            pixal=local_command('pixal3d','a.png','out.glb',r)
            self.assertIn('--sv-image',pixal)
            self.assertEqual(pixal[pixal.index('--res')+1],'1024')

class HttpTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.studio=Studio(self.temp.name,start_worker=False)
        self.server=create_server(self.studio,'test-token')
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
        self.url=f'http://127.0.0.1:{self.server.server_address[1]}'
    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join()
        self.studio.close();self.temp.cleanup()
    def status(self,path,headers=None):
        req=urllib.request.Request(self.url+path,headers=headers or {})
        try:
            with urllib.request.urlopen(req) as r:return r.status
        except urllib.error.HTTPError as e:return e.code
    def test_auth_origin_and_host_boundaries(self):
        self.assertEqual(self.status('/api/jobs'),401)
        self.assertEqual(self.status('/api/jobs',{'Authorization':'Bearer test-token'}),200)
        self.assertEqual(self.status('/api/jobs',{'Authorization':'Bearer test-token','Origin':'https://attacker.example'}),403)
        self.assertEqual(self.status('/api/jobs',{'Authorization':'Bearer test-token','Host':'attacker.example'}),403)
    def test_static_paths_cannot_traverse(self):
        self.assertEqual(self.status('/%2e%2e/backend/core.py'),404)
        self.assertEqual(self.status('/vendor/three/%2e%2e/%2e%2e/package.json'),404)

if __name__=='__main__':unittest.main()
