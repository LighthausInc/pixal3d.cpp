import io
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from runtime_settings import load_runtime
from runtime_support import download, model_manifest
import hashlib

class RuntimeTests(unittest.TestCase):
    def test_runtime_paths_loaded_without_overriding_environment_or_secrets(self):
        with tempfile.TemporaryDirectory() as folder:
            config=Path(folder)/'runtime.json'
            config.write_text(json.dumps({'TRELLIS_BIN':'configured-engine','TRELLIS_MODELS':'configured-weights','TRIPO_API_KEY':'must-not-load'}))
            with patch.dict(os.environ,{'LH3D_RUNTIME_CONFIG':str(config),'TRELLIS_BIN':'override-engine'},clear=True):
                load_runtime()
                self.assertEqual(os.environ['TRELLIS_BIN'],'override-engine')
                self.assertEqual(os.environ['TRELLIS_MODELS'],'configured-weights')
                self.assertNotIn('TRIPO_API_KEY',os.environ)
    def test_m1_setting_applied_and_explicit_override_preserved(self):
        with tempfile.TemporaryDirectory() as folder,patch('runtime_settings.sys.platform','darwin'),patch('runtime_settings.subprocess.run',return_value=SimpleNamespace(stdout='Apple M1 Max')):
            with patch.dict(os.environ,{'LH3D_RUNTIME_CONFIG':str(Path(folder)/'missing')},clear=True):
                load_runtime();self.assertEqual(os.environ['TRELLIS_FA_FAST'],'1')
                os.environ['TRELLIS_FA_FAST']='0'
                load_runtime();self.assertEqual(os.environ['TRELLIS_FA_FAST'],'0')
    def test_pinned_512_manifest_excludes_1024_flows(self):
        base=model_manifest();full=model_manifest(True)
        self.assertEqual(len(base['files']),8)
        self.assertEqual(len(full['files']),10)
        self.assertEqual(sum(f['size_bytes'] for f in base['files']),7244855648)
        self.assertTrue(all(len(f['sha256'])==64 for f in full['files']))
    def test_verified_existing_download_uses_no_network(self):
        with tempfile.TemporaryDirectory() as folder:
            (Path(folder)/'file.gguf').write_bytes(b'weights')
            item={'name':'file.gguf','size_bytes':7,'sha256':hashlib.sha256(b'weights').hexdigest(),'url':'https://example.invalid/weights'}
            with patch('runtime_support.urllib.request.urlopen',side_effect=AssertionError('network called')):
                download(item,folder)
            with self.assertRaises(ValueError):download({**item,'name':'../escape'},folder)

if __name__=='__main__':unittest.main()
