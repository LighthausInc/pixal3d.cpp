import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {generateTripo,credentialScopedFetch} from '../backend/tripo.mjs';
test('Smart retopology reuses the original remote mesh and bakes textures without regenerating',async()=>{
  const folder=await mkdtemp(path.join(os.tmpdir(),'lh3d-retopo-'));
  try{
    let calls=0;
    const client={textToModel:()=>{throw Error('Must not regenerate');},decimateMesh:async params=>{calls++;assert.deepEqual(params,{input:'original-task',model:'v2.0',face_limit:10000,quad:false,bake:true});return 'retopo-task';},
      waitForTask:async()=>{assert.equal(JSON.parse(await readFile(path.join(folder,'remote.json'),'utf8')).task_id,'retopo-task');return {status:'success',credits_consumed:30};},downloadModel:async()=>({data:Buffer.from('glTFasset')})};
    await generateTripo({data_class:'synthetic',tripo_operation:'retopology',input:'original-task',face_limit:10000},folder,client);
    assert.equal(calls,1);assert.equal(JSON.parse(await readFile(path.join(folder,'remote.json'),'utf8')).credits_consumed,30);
  }finally{await rm(folder,{recursive:true,force:true});}
});
test('Tripo API credentials are stripped from signed model downloads',async()=>{
  const seen=[];
  const scoped=credentialScopedFetch(async(url,options)=>{seen.push({url,key:options.headers.get('Authorization')});});
  await scoped('https://openapi.tripo3d.ai/v3/tasks/task',{headers:{Authorization:'Bearer secret'}});
  await scoped('https://assets.example.com/model.glb',{headers:{Authorization:'Bearer secret'}});
  assert.equal(seen[0].key,'Bearer secret');assert.equal(seen[1].key,null);
});
test('Tripo adapter refuses clinical inputs before submission',async()=>{
  await assert.rejects(()=>generateTripo({data_class:'clinical'},'',{textToModel(){throw Error('must not call');}}),/classification/);
});
test('Tripo stores remote task before polling and immediately saves GLB',async()=>{
  const folder=await mkdtemp(path.join(os.tmpdir(),'lh3d-test-'));
  try{
    const client={textToModel:async()=> 'remote-123',waitForTask:async id=>{assert.equal(JSON.parse(await readFile(path.join(folder,'remote.json'),'utf8')).task_id,id);return {status:'success'};},downloadModel:async()=>({data:Buffer.from('glTFasset')})};
    const result=await generateTripo({data_class:'synthetic',prompt:'vessel',seed:42},folder,client);
    assert.equal(result.task_id,'remote-123');assert.equal((await readFile(path.join(folder,'raw.glb'))).toString(),'glTFasset');
  }finally{await rm(folder,{recursive:true,force:true});}
});
