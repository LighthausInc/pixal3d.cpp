"""Explicit real-Blender round-trip test: python tests/integration_refinement.py --state PATH."""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import struct
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'backend'))
from core import Studio

def wait(studio, job):
    deadline = time.monotonic() + 180
    while time.monotonic() < deadline:
        current = studio.get(job['id'])
        if current['status'] == 'succeeded': return current
        if current['status'] not in ('queued', 'running'): raise RuntimeError(current)
        time.sleep(.2)
    raise TimeoutError('Blender workflow exceeded three minutes')

def materials_by_object(path):
    data = path.read_bytes()
    size = struct.unpack_from('<I', data, 12)[0]
    doc = json.loads(data[20:20 + size])
    return {n['extras']['lighthaus_object_id']: [doc['materials'][p['material']] for p in doc['meshes'][n['mesh']]['primitives']]
            for n in doc['nodes'] if 'mesh' in n}

parser=argparse.ArgumentParser()
parser.add_argument('--state', required=True)
args=parser.parse_args()
studio=Studio(args.state)
try:
    original=wait(studio, studio.submit({'provider':'blender','recipe':'robot','prompt':'Selective refinement robot','data_class':'synthetic'}))
    source=studio.state / original['id'] / 'asset.glb'
    imported=wait(studio, studio.import_asset({'name':'Imported robot','data_class':'synthetic','glb_base64':base64.b64encode(source.read_bytes()).decode()}))
    inventory=imported['object_inventory']
    assert len(inventory)==9, inventory
    assert {o['id'] for o in original['object_inventory']} == {o['id'] for o in inventory}
    head=next(o for o in inventory if o['name']=='Head')
    parent_path=studio.state / imported['id'] / 'asset.glb'
    parent_hash=hashlib.sha256(parent_path.read_bytes()).hexdigest()
    edited=wait(studio, studio.edit(imported['id'],{'operation':'material','object_id':head['id'],'material_slot':0,'color':'#22aacc','metallic':.8}))
    before=materials_by_object(parent_path)
    after=materials_by_object(studio.state / edited['id'] / 'asset.glb')
    assert before[head['id']] != after[head['id']]
    assert all(before[id]==after[id] for id in before if id != head['id']), 'An unselected object material changed'
    assert parent_hash==hashlib.sha256(parent_path.read_bytes()).hexdigest(), 'Parent asset changed'
    reduced=wait(studio, studio.edit(edited['id'],{'operation':'decimate','object_id':head['id'],'ratio':.5}))
    earlier={o['id']:o['triangles'] for o in edited['object_inventory']}
    later={o['id']:o['triangles'] for o in reduced['object_inventory']}
    assert later[head['id']] < earlier[head['id']]
    assert all(later[id]==earlier[id] for id in earlier if id != head['id']), 'An unselected object geometry changed'
    report={'status':'passed','objects':9,'original_id':original['id'],'imported_id':imported['id'],'material_child_id':edited['id'],
            'geometry_child_id':reduced['id'],'selected_object':head,'parent_sha256':parent_hash,
            'head_triangles_before':earlier[head['id']],'head_triangles_after':later[head['id']],
            'unchanged_other_objects':8,'blender_version':reduced['blender_version']}
    (studio.state / 'integration-report.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    print(json.dumps(report),flush=True)
finally:
    studio.close()
