"""Actual Blender GUI/timer + HTTP round trip, no paid calls and no user's scene.
Run with Python from the repo root. Artifacts go to the supplied workspace state.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import struct
import sys
import threading
import time
import urllib.request
import uuid
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'backend'))
from core import Studio, find_blender
from server import create_server

parser=argparse.ArgumentParser()
parser.add_argument('--state',required=True)
parser.add_argument('--source',required=True)
args=parser.parse_args()
state=Path(args.state).resolve();state.mkdir(parents=True,exist_ok=True)
studio=Studio(state)
token=secrets.token_urlsafe(32)
server=create_server(studio,token)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
url=f'http://127.0.0.1:{server.server_address[1]}'
(state/'session.json').write_text(json.dumps({'url':url,'token':token}))
source=Path(args.source).resolve()
source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
source_id=uuid.uuid4().hex
(state/source_id).mkdir()
shutil.copy2(source,state/source_id/'asset.glb')
studio.save({'id':source_id,'name':'Aster live round trip','status':'succeeded','request':{'provider':'blender'},'operations':[]})
stop=state/'stop-blender'
if stop.exists():stop.unlink()
config={'addon':str(root/'blender/studio_link.py'),'session_file':str(state/'session.json'),'stop_file':str(stop)}
(state/'host.json').write_text(json.dumps(config))
startup=None
if os.name=='nt':
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
log=(state/'blender-live.log').open('w')
process=subprocess.Popen([find_blender(),'--factory-startup','--disable-autoexec','--python',str(root/'tests/blender_live_host.py'),'--',str(state/'host.json')],stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,
                         env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ('API_KEY','TOKEN','SECRET'))})
def request(path,body=None):
    req=urllib.request.Request(url+path,None if body is None else json.dumps(body).encode(),{'Authorization':'Bearer '+token,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=15) as r:return json.loads(r.read())
def until(check,seconds=60):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        value=check()
        if value:return value
        if process.poll() is not None:raise AssertionError('Blender exited; inspect log')
        time.sleep(.2)
    raise AssertionError('Timed out; inspect live status and log')
commands=[]
def command(op,params=None):
    body={'command_id':uuid.uuid4().hex,'operation':op,'args':params or {}}
    record=request('/api/blender/command',body)
    def done():
        status=request('/api/blender')
        item=next((c for c in status['commands'] if c['id']==record['id']),None)
        return item if item and item['status'] in ('succeeded','failed') else None
    result=until(done)
    assert result['status']=='succeeded',result
    assert request('/api/blender/command',body)['status']=='succeeded','Retry must not enqueue'
    commands.append(result)
    return result['result']
def pbr_resources(file):
    data=Path(file).read_bytes()
    size=struct.unpack_from('<I',data,12)[0]
    doc=json.loads(data[20:20+size]);binary=data[28+size:]
    images=[]
    for image in doc.get('images',[]):
        view=doc['bufferViews'][image['bufferView']]
        start=view.get('byteOffset',0)
        images.append((image['mimeType'],hashlib.sha256(binary[start:start+view['byteLength']]).hexdigest()))
    return {'images':images,'materials':doc.get('materials',[]),'textures':doc.get('textures',[])}
try:
    until(lambda:request('/api/blender')['connected'])
    before=command('inspect')['snapshot']
    created=command('create_primitive',{'shape':'cylinder','name':'Studio signal beacon','location':[1,0,0]})
    object_id=created['created_id']
    command('transform',{'object_ids':[object_id],'location':[.8,0,.5],'rotation':[0,0,15],'scale':[.1,.1,.3]})
    material=command('material',{'object_ids':[object_id],'material_slot':0,'color':'#13a6aa','metallic':.65})
    assert next(o for o in material['snapshot']['objects'] if o['id']==object_id)['materials'][0]['name'].startswith('Studio material')
    reduced=command('decimate',{'object_ids':[object_id],'ratio':.5})
    assert len(next(o for o in reduced['snapshot']['objects'] if o['id']==object_id)['modifiers'])==1
    imported=command('import_asset',{'job_id':source_id})
    imported_ids=imported['imported_ids']
    assert imported_ids
    # Unrelated existing scene objects retain geometry/transforms/material slots.
    current={o['id']:o for o in imported['snapshot']['objects']}
    for original in before['objects']:
        for key in ('triangles','location','scale','materials'):
            assert current[original['id']][key]==original[key],key
    exported=command('export_asset',{'object_ids':imported_ids})
    child_id=exported['job_id']
    child=until(lambda:(j if (j:=studio.get(child_id))['status'] in ('succeeded','failed') else None))
    assert child['status']=='succeeded',child
    assert child['parent_id']==source_id
    assert child['metrics']['triangles']==10000,child['metrics']
    assert child['metrics']['materials']==1
    assert pbr_resources(source)==pbr_resources(state/child_id/'asset.glb'),'PBR material or embedded texture bytes changed'
    assert all(c['result']['snapshot']['execution_thread']=='MainThread' for c in commands)
    assert hashlib.sha256(source.read_bytes()).hexdigest()==source_hash
    report={'passed':True,'blender_version':before['blender_version'],'source_sha256':source_hash,'child_job':child_id,
            'pbr_verification':{'embedded_images':len(pbr_resources(source)['images']),'material_definitions_unchanged':True,'texture_bytes_sha256_unchanged':True},
            'metrics':child['metrics'],'execution':'Real Blender GUI application timers; bpy ran on MainThread',
            'commands':[{k:c[k] for k in ('id','operation','status')} for c in commands],
            'deduplication':'Each completed command resubmitted with same ID; no duplicate objects/modifiers/exports'}
    (state/'integration-report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report),flush=True)
finally:
    stop.touch()
    try:process.wait(timeout=20)
    except subprocess.TimeoutExpired:process.terminate();process.wait(timeout=10)
    log.close();server.shutdown();server.server_close();thread.join();studio.close()
    (state/'session.json').unlink(missing_ok=True)
