import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'backend'))
from native import verify_native

class ManifestTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        (self.root / 'engine').write_bytes(b'engine')
        self.manifest = {'schema_version': 1, 'provider': 'trellis', 'revision': 'pinned', 'files': []}
        for name in ('dinov3', 'shape_dec', 'ss_dec', 'ss_flow', 'tex_dec', 'shape_flow_512', 'tex_flow_512'):
            data = name.encode()
            (self.root / (name + '.gguf')).write_bytes(data)
            self.manifest['files'].append({'name': name + '.gguf', 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)})
        self.env = patch.dict(os.environ, {'TRELLIS_BIN': str(self.root / 'engine'), 'TRELLIS_MODELS': str(self.root)})
        self.env.start()
        self.save()
    def save(self):
        (self.root / 'manifest.json').write_text(json.dumps(self.manifest))
    def tearDown(self):
        self.env.stop()
        self.temp.cleanup()
    def test_verified_identity_and_tamper_detection(self):
        first = verify_native('trellis', 512)
        self.assertEqual(first['models']['revision'], 'pinned')
        self.assertEqual(len(first['models']['files']), 7)
        (self.root / 'ss_dec.gguf').write_bytes(b'broken')
        with self.assertRaisesRegex(ValueError, 'integrity'):
            verify_native('trellis', 512)
    def test_no_incomplete_resolution_profile(self):
        with self.assertRaisesRegex(ValueError, 'required'):
            verify_native('trellis', 1024)
        self.manifest['files'].pop()
        self.save()
        with self.assertRaisesRegex(ValueError, 'required'):
            verify_native('trellis', 512)
    def test_manifest_path_traversal_and_provider_rejected(self):
        self.manifest['files'][0]['name'] = '../outside.gguf'
        self.save()
        with self.assertRaisesRegex(ValueError, 'filename'):
            verify_native('trellis', 512)
        self.manifest['provider'] = 'pixal3d'
        self.save()
        with self.assertRaisesRegex(ValueError, 'provider'):
            verify_native('trellis', 512)

if __name__ == '__main__': unittest.main()
