import json
import sys
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'backend'))
from core import Studio
from blender_bridge import BlenderBridge


class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.studio=Studio(self.temp.name,start_worker=False)
        self.bridge=BlenderBridge(self.studio)
        self.peer='a'*32
        self.bridge.connect({'peer_id':self.peer,'version':'test'})
    def tearDown(self):
        self.studio.close();self.temp.cleanup()
    def command(self, **extra):
        return {'command_id':'b'*32,'operation':'create_primitive','args':{'shape':'cube'},**extra}
    def test_enqueue_retry_and_claim_are_not_replayed(self):
        first=self.bridge.enqueue(self.command())
        self.assertEqual(self.bridge.enqueue(self.command())['id'],first['id'])
        self.assertEqual(self.bridge.poll({'peer_id':self.peer})['command']['id'],first['id'])
        self.assertIsNone(self.bridge.poll({'peer_id':self.peer})['command'])
        done=self.bridge.complete({'peer_id':self.peer,'command_id':first['id'],'result':{'created_id':'c'*32}})
        self.assertEqual(done['status'],'succeeded')
        self.assertEqual(self.bridge.enqueue(self.command())['status'],'succeeded')
        self.assertIsNone(self.bridge.poll({'peer_id':self.peer})['command'])
        with self.assertRaises(ValueError):self.bridge.enqueue(self.command(args={'shape':'sphere'}))
    def test_restart_leaves_claimed_command_uncertain(self):
        self.bridge.enqueue(self.command())
        self.bridge.poll({'peer_id':self.peer})
        restarted=BlenderBridge(self.studio)
        self.assertEqual(restarted.get('b'*32)['status'],'uncertain')
        restarted.connect({'peer_id':'d'*32})
        self.assertIsNone(restarted.poll({'peer_id':'d'*32})['command'])
    def test_invalid_parameters_and_arbitrary_code_fail_closed(self):
        for change in ({'operation':'python','args':{'code':'print(1)'}},
                       {'args':{'shape':'cube','location':[float('nan'),0,0]}},
                       {'operation':'transform','args':{'object_ids':['../file']}},
                       {'operation':'import_asset','args':{'job_id':'../../secret'}}):
            with self.assertRaises(ValueError):self.bridge.enqueue(self.command(**change))
    def test_other_session_cannot_claim_or_complete(self):
        self.bridge.enqueue(self.command())
        for call in (lambda:self.bridge.connect({'peer_id':'d'*32}), lambda:self.bridge.poll({'peer_id':'d'*32}),
                     lambda:self.bridge.complete({'peer_id':'d'*32,'command_id':'b'*32,'result':{}})):
            with self.assertRaises(ValueError):call()
    def test_export_destination_is_service_owned(self):
        job=self.bridge.enqueue(self.command(operation='export_asset',args={'object_ids':['c'*32],'destination':'C:/outside.glb'}))
        self.assertEqual(Path(job['args']['destination']).parent,self.studio.state/'live-exports')
    def test_disconnect_marks_mutation_uncertain_and_allows_new_peer(self):
        self.bridge.enqueue(self.command())
        self.bridge.poll({'peer_id':self.peer})
        self.bridge.disconnect({'peer_id':self.peer})
        self.assertEqual(self.bridge.get('b'*32)['status'],'uncertain')
        self.bridge.connect({'peer_id':'c'*32})
        self.assertIsNone(self.bridge.poll({'peer_id':'c'*32})['command'])
    def test_missing_export_fails_without_hanging_the_queue(self):
        self.bridge.enqueue(self.command(operation='export_asset',args={'object_ids':['c'*32]}))
        self.bridge.poll({'peer_id':self.peer})
        result=self.bridge.complete({'peer_id':self.peer,'command_id':'b'*32,'result':{}})
        self.assertEqual(result['status'],'failed')

if __name__=='__main__':unittest.main()
