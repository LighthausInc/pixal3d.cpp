# Application architecture and implementation plan

Decision date: 2026-10-03. Status: **provisional, pending real inference benchmarks**.

## Existing goals found

The intended repository is [LighthausInc/pixal3d.cpp](https://github.com/LighthausInc/pixal3d.cpp). Its 57 issues already provide a substantial roadmap. The core application epic is [#22](https://github.com/LighthausInc/pixal3d.cpp/issues/22), with provider adapters [#28–33](https://github.com/LighthausInc/pixal3d.cpp/issues/28), job orchestration [#34–38](https://github.com/LighthausInc/pixal3d.cpp/issues/34), Blender [#39–43](https://github.com/LighthausInc/pixal3d.cpp/issues/39), review [#44–48](https://github.com/LighthausInc/pixal3d.cpp/issues/44), Unity export [#49–52](https://github.com/LighthausInc/pixal3d.cpp/issues/49), and CLI/MCP [#53–56](https://github.com/LighthausInc/pixal3d.cpp/issues/53). Issues #2–10 and #23–27 specify the security baseline.

Those issues focus on mfm-quest storyboard assets, but the current request is broader: a bespoke personal modeling workbench on Windows **and Apple Silicon**, local inference on both, premium generation including Tripo, and strong Blender interfaces. Keep Quest presets as a later optional export profile. Prioritize Tripo ahead of fal.ai because the user explicitly named it.

## Application and engine boundaries

Start a separate **3dgen-studio** application repository. Retain both native engines; avoid rewriting their model kernels. Do not create a new GitHub repository or copy the old engine's complete history merely to build the product layer. The current local deliverable is the seed for that application repository.

| Layer | Choice | Why |
|---|---|---|
| Desktop shell | Electron, sandboxed renderer, narrow application service | Predictable Chromium PBR preview on both platforms; TypeScript/JavaScript ecosystem and native packaging tooling |
| UI | Web modules + Three.js in prototype; React/TypeScript after workflow settles | Keep the first slice small; production type checking and component structure can follow |
| Orchestration | Python service + SQLite | Matches the existing issues; works with native executables and Blender; no torch in the UI |
| Local providers | trellis.cpp and pixal3d.cpp CLI subprocess adapters | Existing CUDA/Metal code; process isolation; easy replacement; stable C ABI later |
| Premium providers | Official Tripo SDK; Rodin next | Shared request/job/asset interface and centrally logged cost policy |
| Blender | Headless worker plus opt-in main-thread live add-on | Repeatable edits today, interactive round trip without arbitrary-code agent tools later |
| Agent interface | Official MCP SDK over stdio | Same jobs, approvals and operations as the UI |
| Persistence | SQLite jobs + per-version manifests + GLB/.blend/provenance | Reviewable output, lineage and crash visibility |

Electron is an application packaging choice, not a solution to GPU inference portability. The C++ engine must still be built for CUDA/Metal, shipped with matching dependencies, and supplied compatible weights. Tauri remains a reasonable alternative: both reference repos already include Tauri Studio. Choose Electron provisionally for consistent rendering and fast prototyping; measure installed size, memory and viewport fidelity before treating it as irreversible. Python is externally installed in 0.1; production packaging must bundle a controlled runtime. Do not claim an Electron build alone is a self-contained 3D generator.

## Native engine reuse, including Mac

Inspected source revisions:

- Upstream `pwilkin/trellis.cpp`: `c0bed38c1578f7e36e3e50c8ff1e38fa0d47583f`.
- Lighthaus fork `pixal3d.cpp`: `d1b4926452f9e09702b891db5f05acc845e153ed`.

[Issue #1](https://github.com/LighthausInc/pixal3d.cpp/issues/1) recommends upstream trellis.cpp, with a selective Pixal3D multiview port after benchmark #14. Preserve that as a provisional recommendation rather than declaring its acceptance criteria satisfied without benchmark data.

The [upstream README](https://github.com/pwilkin/trellis.cpp/blob/c0bed38c1578f7e36e3e50c8ff1e38fa0d47583f/README.md) reports verified Metal inference on an M5 with 24 GB unified memory (512-resolution textured generation, 9m21s, 5.6 GB peak RSS). This is upstream's reported measurement, not our own test. Metal defaults on for Apple builds, with CPU fallback for selected custom operations. Reference Microsoft Python TRELLIS.2 is CUDA/Linux oriented; its requirements should not be applied directly to the GGML port.

The [Pixal3D fork](https://github.com/LighthausInc/pixal3d.cpp) already contributes camera-aware multiview inference, canonical camera metadata, single-view crop/gauge handling, model manifests, VRAM splitting, and Metal-specific conditioning optimizations. Reuse the existing runnable fork immediately through its own adapter. Then port isolated changes only if quality/performance data justify them. Multi-view contracts differ: upstream Pixal3D `--model pixal3d` uses an explicit FOV in degrees; the fork's `--sv-image` path prepares its own gauge and uses different flags. Keep adapters distinct to avoid mixing those contracts.

Current Windows hardware: RTX 3090, 24,576 MiB VRAM. Blender 5.1.0 installed. Target Mac confirmed by the user: M1 Max with 64 GB unified memory. Thermal behavior and benchmark access remain to be established. Do not promise parity on every Apple Silicon model. Current upstream documents a special M1 attention setting; capture hardware and effective configuration in every benchmark.

Rodin is a premium Hyper3D provider in the existing [#31](https://github.com/LighthausInc/pixal3d.cpp/issues/31). Its [official documentation](https://docs.hyper3d.ai/en) does not establish an OSS local production-weight path here. Keep Rodin in the API lane unless a concrete licensed local model is identified. Local candidates include TRELLIS.2 and Pixal3D; evaluate alternatives after these benchmarks.

## Target flow

```mermaid
flowchart LR
  UI[Electron workbench] --> S[Shared service]
  MCP[MCP agents] --> S
  CLI[CLI / batches] --> S
  S --> Q[SQLite jobs + policy]
  Q --> T[TRELLIS / Pixal3D native workers]
  Q --> A[Tripo / Rodin APIs]
  T --> V[Versioned GLB + provenance]
  A --> V
  V --> B[Blender headless and live link]
  B --> R[Render / compare / review]
  R --> E[GLB and target export profiles]
  R --> Q
```

Providers should eventually expose typed capabilities, estimate, submit, poll, cancel and fetch, matching [#29](https://github.com/LighthausInc/pixal3d.cpp/issues/29). Versioned operation requests should refer to asset IDs rather than arbitrary filesystem paths or scripts. Keep model-specific views/parameters in adapters, not in the desktop shell. The initial service has a provider registry and shared records but is not yet the fully typed plugin protocol.

## Milestones and acceptance criteria

| Milestone | Scope | Acceptance / issue links |
|---|---|---|
| 0 · first vertical slice | Procedural Blender, persistent jobs, PBR viewer, headless edits, review, exports, stdio MCP, native/Tripo adapters | A real GLB survives create → inspect → material → decimate → normalize → approve; source and capability status are visible. Partial #29, #35, #36, #41, #46, #55, #56 |
| 1 · local inference on both OSes | Pin and install both engines; verified model manifests; CUDA build and Metal build; record license metadata | Generate ultrasound monitor, probe and laryngoscope with identical refs/seeds; measure time, peak memory, geometry and visual ratings on RTX 3090 and the actual Mac. #1, #6, #11, #14, #30; model verification/benchmark prerequisite for permanent engine choice |
| 2 · desktop readiness and premium path | Bundle Python/runtime dependencies; signed installers; keychain settings; Tripo text/image; remote task reconciliation; typed API schemas | Windows portable build and Mac arm64 build launch; Tripo dry-run costs nothing; one explicitly authorized real Tripo job downloads immediately and records actual usage. #24, #25, #29, #33, #35, #56 |
| 3 · Blender workflow quality | Live add-on, import/pull versioning, object IDs, operation log, real render previews, per-object material edits, shape primitives and transforms | UI and MCP create simple objects and tweak named regions; parent GLB round trip preserves UV/PBR; reconnect does not rerun operations. #39, #41, #42, #45, #55 |
| 4 · multiview and finish pipeline | Reuse fork's camera contracts and 4-view rig; evaluate Finish scripts before reuse; clean components, UV/bake, LOD, retopology budget | Test whether MV improves a trial asset and whether cleanup fits budget without manual work; retain attribution for reused scripts. #40, #41, #43, #14 |
| 5 · richer providers and review | Rodin, optional fal.ai, side-by-side candidates, notes to child jobs, cost/time/acceptance metrics | Same asset request routes across providers; reviews and operations are tied to immutable versions. #31, #32, #44–48 |
| 6 · advanced orchestration and export | Cache/resume, remote GPU worker, C ABI if needed, optional Quest/Unity exports | Kill/restart without duplicate paid submission; deterministic cache invalidation; target-profile validation and attribution. #17, #21, #37, #38, #49–52, #54 |

First local validation completed: upstream v0.8.1 CUDA with pinned Q8 GGUF weights generated a textured vessel at resolution 512 / seed 42 in 65.0 seconds of engine time, 84.95 seconds including model verification and Blender processing. Output: 144,520 triangles, one material. This is a single functional test, not the full asset-quality benchmark. Next run the remaining benchmark matrix on RTX 3090, compare the fork and collect matching results on the M1 Max / 64 GB Mac. Preserve raw outputs and a shared scoring sheet.

## Engineering decisions for the next iteration

1. Export Pydantic/JSON schemas and replace raw registry branching with providers that declare supported input and output capabilities.
2. Add immutable artifact hashes and engine/model/license identities. Current edited versions reference the source generation request plus an operation chain; verify this remains replayable as the pipeline grows.
3. Use atomic transaction/outbox records and a reconcile state for cloud submission. Task-ID persistence reduces duplicate retry risk but does not eliminate the crash gap after provider acceptance.
4. Implement cost estimates per actual provider/model and record actual billed credits separately from reservations. Do not treat user approval as proof that a provider charge can never exceed an estimate.
5. Keep main-thread Blender execution. The live add-on should accept validated operations through a queue consumed by `bpy.app.timers`; no unrestricted Python `exec` endpoint. Track stable object IDs and material slot targets. Add non-destructive modifier operations first.
6. Scope imports/exports to registered assets and dialog-selected paths. Keep localhost authentication/Origin/Host checks. Complete OS sandbox, Windows ACL and signed model/binary verification before processing unknown assets. Follow [#23–27](https://github.com/LighthausInc/pixal3d.cpp/issues/23).
7. Benchmark engine forks, viewport memory and large-GLB import behavior. Native quad retopology, UV correctness and PBR retention matter more than the choice of shell alone.

The pinned upstream CUDA release and Q8 GGUF weights are installed and hash-verified. Real Windows vessel and robot generations, funded Tripo generation, and live Blender round trips have passed. Mac and fork benchmarks remain open. No GitHub issues were changed or closed. The original fork remains the roadmap/reference repository until a remote home for the application is chosen.
