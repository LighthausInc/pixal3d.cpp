# Tripo setup

Create a key at [Tripo API Keys](https://platform.tripo3d.ai/api-keys), then open Connections in Studio. Paste the key into the password field and press Connect for this session. The panel closes and selects Tripo. No paid job starts when you connect.

The password field clears after connection. The credential stays in the backend process for this app session and is passed only to the Tripo helper. It is not saved in application files, browser storage, job records, or Blender/native-worker environments. Persistent OS keychain integration is still planned. Do not paste the key in chat or source files.

The form prefills model `v3.1-20260211` and a $5 per-job reservation ceiling / daily budget, matching the user's initial test authorization. The ceiling is not the expected bill: [official pricing](https://developers.tripo3d.ai/en/pricing) lists H-series standard textured text generation at 20 credits ($0.20), checked 2026-10-03. Verify current pricing when changing models or options.

A live balance request succeeded in this session and returned zero available API credits. The first generation was rejected with provider code 2010 before creating a task. Its local reservation was released. After the user funded the API wallet, the real observatory robot test succeeded and consumed 20 credits ($0.20 equivalent). Use the cloud panel's Check API credit balance button to read available/frozen API credits without submitting a task. Studio subscriptions remain separate from API credit top-ups.

Choose Tripo, describe a simple original object, select Synthetic/original artwork or Licensed reference, click Estimate, approve its displayed ceiling and then Create asset. The estimate makes no paid call. Reservations enforce a UTC daily cap. Ambiguous submission failures retain their reservation until reconciled with the provider; do not blindly retry them.

Alternative launch-time configuration: use the `Start-Studio.ps1 -ConfigureTripo` switch together with `-TripoModel`, `-TripoEstimateUsd` and `-DailyCapUsd`. It prompts for hidden key input. Environment variables are also supported; see Connections. No command-line API key argument is needed.
