# Apple Silicon validation target

User target: **M1 Max, 64 GB unified memory**. No generation has yet been measured on this Mac. The Windows CUDA results must not be presented as Mac validation.

## Prepared setup and benchmark

The official v0.8.1 release has CUDA/ROCm/Vulkan archives but no Metal archive. The Mac installer builds the exact v0.8.1 source commit `367f06722e6c482d8a46d94509be326409066d4a` and its GGML submodule commit `f8697b33795db2ee6a2569b40853ca6aaa69f9b9`. The app's previously inspected repository HEAD is newer; this build deliberately uses the release commit matching Windows. Textures use PNG (`TRELLIS_WEBP=OFF`) to avoid an additional build dependency.

Prerequisites on the Mac: native arm64 Python 3.11+, Node.js 22.12+, CMake, Ninja, Git, Blender, and Apple's Xcode/Metal compiler tools. Verify `xcrun --find metal` succeeds; a Command Line Tools installation alone may not include the Metal toolchain. Setup diagnoses missing tools and does not install system software or request administrator privileges.

From the extracted source directory in Terminal:

```bash
# Print the exact plan without modifying anything.
python3 tools/setup-mac.py --plan

# Build Metal and download the 7.24 GB 512-resolution weight set.
bash Setup-Mac.command

# Run the same robot PNG/512/seed 42 used on RTX 3090.
bash Benchmark-Mac.command

# Install locked app dependencies and create the unsigned arm64 application.
bash Build-Mac.command
```

The setup stores paths in `~/Library/Application Support/Lighthaus3DGen/runtime.json`. The service loads them automatically, including when launched from Finder. Explicit environment paths take precedence. Add `--include-1024` to setup for the additional 1024 flow weights. Default downloads are revision-pinned and checked by size/SHA-256; interrupted downloads can resume. The engine remains in its build directory with its sibling libraries.

The benchmark produces `benchmark.json`, the worker log, GLB, `.blend`, preview, and provenance in a dated folder under the application's `benchmarks` directory. It requires GPU execution, records GPU backend evidence, engine and end-to-end time, macOS/hardware, source/weight identities, M1 settings and geometry. On macOS it records peak child-process resident memory (including Blender), which is not equivalent to GPU memory. Send back the JSON and preview to assess the M1 result.

The runner has been exercised on Windows. The Mac build, runtime and installer execution remain **unverified until run on the M1 Max**. Electron Builder explicitly rejects building macOS artifacts on Windows; no Mac binary is claimed from this Windows session. The unsigned development app is not a signed/notarized distribution.

The application keeps the C++/GGML engines. `Start-Studio.command` detects an M1 brand string and sets `TRELLIS_FA_FAST=1` unless explicitly configured otherwise, following the [pinned upstream README](https://github.com/pwilkin/trellis.cpp/blob/c0bed38c1578f7e36e3e50c8ff1e38fa0d47583f/README.md). Upstream's published M5 result is useful feasibility evidence, not a performance estimate for M1 Max.

Mac acceptance run:

1. Build or install a pinned arm64 Metal native engine and matching weights. Record commit/tag, executable hash, model manifest, macOS version, hardware and effective attention configuration. Verify source-specific model licenses separately.
2. Configure `TRELLIS_BIN` and `TRELLIS_MODELS`, install Blender and Python 3.11+, and install the app dependencies with Node 22.12+. Run `npm run pack:mac` on the Mac and launch the application. The current unsigned prototype uses an external Python runtime.
3. Run the same RGBA reference used for the Windows test at resolution 512 and seed 42, with `--require-gpu`. Preserve worker logs proving Metal execution rather than silently accepting CPU-only inference. Record wall time, peak memory, final GLB hash, dimensions, triangle count and material count.
4. Inspect the GLB in Studio and Blender. Create a material child and a geometry child; verify parent files are unchanged. Save review notes, restart, and verify history and downloads.
5. Repeat with the Pixal3D fork and its own weights/CLI contract, then compare silhouette, texture and geometry. Only expand to 1024 after the 512 baseline completes reliably. Fork single-view currently enforces at least 1024 and needs a pre-matted RGBA image.

Signing, notarization, bundled Python, installation permissions, model installation UI and a real Metal benchmark remain separate unfinished acceptance items.
