# Live Blender workflow

Studio Link connects a running Blender scene to the application's UI and MCP tools. Blender executes all edits on its main thread through an application timer. The add-on's background thread handles only authenticated loopback requests; it opens no listening port.

## Connect

1. Start Studio. Expand **Live Blender scene** in the right-hand refinement panel and download `studio_link.py`.
2. In Blender Preferences, install that file as a legacy add-on and enable **Lighthaus Studio Link**. Blender 5.1 on Windows is tested; Mac execution still needs validation.
3. Open the 3D View sidebar and its **Studio Link** tab. Select the `session.json` file shown in Studio and click **Connect to Studio**. This file contains a local session token; the UI displays its path, never its contents.
4. Click **Inspect live scene** in Studio. Choose a live object to edit its material or transform, or select a completed Studio asset and choose **Send selected asset to Blender**.
5. **Pull object into Studio** exports the chosen object and creates a new version with GLB, editable `.blend`, preview, geometry metrics and lineage. The original asset remains intact.

Keep Blender in Object Mode for mutations. Material controls replace the selected material slot; they do not perform texture painting. Live reduction adds a non-destructive Decimate modifier, applied in the exported GLB. Transforms are absolute local XYZ values, with rotation in degrees. Objects created or duplicated manually are assigned distinct stable IDs when inspected.

## MCP

`blender_live_status` returns connection state, the last object inventory and command results. Refresh the scene with an `inspect` command after manual Blender edits.

`blender_live_command` accepts `command_id` (32 lowercase hexadecimal characters), `operation`, and `args`. Operations:

| Operation | Arguments |
|---|---|
| `inspect` | None |
| `import_asset` | Completed Studio `job_id` |
| `create_primitive` | `shape`: cube, sphere or cylinder; optional `name`, `location` |
| `transform` | `object_ids`, `location`, `rotation` in degrees, `scale` |
| `material` | `object_ids`, `material_slot`, hex `color`, `roughness`, `metallic` |
| `decimate` | `object_ids`, `ratio` |
| `export_asset` | `object_ids`; returns a Studio `job_id` once export is accepted |

Generate a command ID once and reuse it with identical arguments if a request or acknowledgement is retried. A command is claimed once, and the SQLite ledger prevents replay of completed operations. Studio restart marks claimed work uncertain. Inspect the scene before issuing a replacement command; reconnect does not replay scene mutations. A disconnected Blender session cannot claim another session's commands. Export IDs are deterministic, preventing duplicate child jobs on acknowledgement retry.

## Verified and remaining limits

The integration test starts a separate hidden Blender GUI instance and exercises its real application timer: inspect, cylinder creation, transform, material, reduction modifier, import and export. Every operation reports `MainThread`. Repeated command IDs do not add duplicate modifiers or objects. Unrelated scene objects remain unchanged. The Aster round trip retains 10,000 triangles, its dimensions, one PBR material and source lineage. The test instance then exits.

The bridge does not save or overwrite the user's open `.blend` file. Save normally in Blender. Undo support uses Blender's undo stack for mutation boundaries; automatic cross-process rollback is not implemented. One Blender instance connects at a time. Scene inventory refresh is explicit after manual edits. Arbitrary Python, shell commands and arbitrary import/export paths are not accepted. This is not an OS-level sandbox for untrusted model files.

Reproduce with `python tests/integration_live_blender.py --state <temporary-state> --source <aster-blender-10k.glb>`. Run from the application directory with Blender installed. The test checks the specific 10,000-triangle fixture.
