param([string]$Python, [string]$State, [switch]$ConfigureTripo,
      [string]$TripoModel, [decimal]$TripoEstimateUsd, [decimal]$DailyCapUsd = 5)
$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
if ($ConfigureTripo) {
    if (-not $TripoModel -or $TripoEstimateUsd -le 0 -or $DailyCapUsd -lt $TripoEstimateUsd) {
        throw 'Supply -TripoModel, a positive -TripoEstimateUsd, and -DailyCapUsd at least as large as the estimate. Verify the model and cost in your Tripo console first.'
    }
    $privateKey = Read-Host 'Tripo API key (hidden; used only for this launch)' -AsSecureString
    $keyPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($privateKey)
    try { $env:TRIPO_API_KEY = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($keyPointer) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($keyPointer); $privateKey.Dispose() }
    $env:TRIPO_MODEL = $TripoModel
    $env:TRIPO_ESTIMATE_USD = $TripoEstimateUsd.ToString([Globalization.CultureInfo]::InvariantCulture)
    $env:LH3D_DAILY_CAP_USD = $DailyCapUsd.ToString([Globalization.CultureInfo]::InvariantCulture)
}
if (-not $Python) {
    $candidate = Get-Command python -ErrorAction SilentlyContinue
    if ($candidate -and $candidate.Source -notlike '*WindowsApps*') { $Python = $candidate.Source }
    if (-not $Python) {
        $bundledPython = Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
        if (Test-Path -LiteralPath $bundledPython) { $Python = $bundledPython }
    }
}
if (-not $Python) { throw 'Python 3.11+ required. Use -Python C:\path\to\python.exe.' }
$env:LH3D_PYTHON = $Python
if (-not $env:LH3D_NODE) {
    $bundledNode = Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
    if (Test-Path -LiteralPath $bundledNode) { $env:LH3D_NODE = $bundledNode }
}
if ($State) { $env:LH3D_STATE = $State }
$packed = Join-Path $taskRoot 'dist/win-unpacked/Lighthaus 3DGen.exe'
$dev = Join-Path $taskRoot 'node_modules/electron/dist/electron.exe'
try { if (Test-Path -LiteralPath $packed) {
    Start-Process -FilePath $packed -WorkingDirectory $taskRoot -WindowStyle Hidden
} elseif (Test-Path -LiteralPath $dev) {
    Start-Process -FilePath $dev -ArgumentList '.' -WorkingDirectory $taskRoot -WindowStyle Hidden
} else { throw 'Run npm ci using Node 22.12+, then npm start.' }
} finally { if ($ConfigureTripo) { Remove-Item Env:TRIPO_API_KEY -ErrorAction SilentlyContinue } }
