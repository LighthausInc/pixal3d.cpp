#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ "$(uname -s)" != Darwin || "$(uname -m)" != arm64 ]]; then
  echo 'Build on an Apple Silicon Mac in a native arm64 terminal.'; exit 1
fi
node -e 'const [major,minor]=process.versions.node.split(".").map(Number);if(process.arch!=="arm64"||major<22||(major===22&&minor<12)){throw Error("Use native arm64 Node.js 22.12 or newer");}'
npm ci
npm run pack:mac
echo 'Unsigned app created in dist/mac-arm64. Launch it on this Mac to complete validation.'
