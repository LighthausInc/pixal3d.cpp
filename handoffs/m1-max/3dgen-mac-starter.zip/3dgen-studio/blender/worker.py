"""Allow-listed Blender operations. All geometry work runs on Blender's main thread."""
import json
import math
from pathlib import Path
import sys
import uuid
import bpy
from mathutils import Vector

spec = json.loads(Path(sys.argv[sys.argv.index("--") + 1]).read_text(encoding="utf-8"))
folder = Path(sys.argv[sys.argv.index("--") + 1]).parent
bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)

def material(color, roughness, metallic, name="Studio material"):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    n = m.node_tree.nodes.get("Principled BSDF")
    def linear(v):
        return v / 12.92 if v <= .04045 else ((v + .055) / 1.055) ** 2.4
    n.inputs["Base Color"].default_value = tuple(linear(int(color[i:i+2], 16) / 255) for i in (1, 3, 5)) + (1,)
    n.inputs["Roughness"].default_value = roughness
    n.inputs["Metallic"].default_value = metallic
    return m

def finish(obj, mat, bevel=.06):
    obj.data.materials.append(mat)
    if bevel:
        mod = obj.modifiers.new("Soft edges", "BEVEL")
        mod.width = bevel
        mod.segments = 3
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.modifier_apply(modifier=mod.name)
    for p in obj.data.polygons:
        p.use_smooth = True
    return obj

def cube(name, location, scale, mat):
    bpy.ops.mesh.primitive_cube_add(size=1, location=location)
    obj = bpy.context.object
    obj.name = name
    obj.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return finish(obj, mat)

if spec["mode"] == "create":
    mat = material(spec["color"], spec["roughness"], spec["metallic"])
    dark = material("#192534", .22, .6, "Dark accent")
    if spec["recipe"] == "vessel":
        # Lathed vessel with a real inner wall and open lip, distinct from a solid cone.
        profile = [(0,0),(.34,0),(.38,.08),(.44,.35),(.38,.66),(.25,.9),(.23,1.2),(.26,1.27),(.21,1.27),(.18,1.19),(.2,.92),(.33,.64),(.38,.34),(.32,.1),(0,.1)]
        verts = [(r*math.cos(i*2*math.pi/64), r*math.sin(i*2*math.pi/64), z) for r,z in profile for i in range(64)]
        faces = [(a*64+i,a*64+(i+1)%64,(a+1)*64+(i+1)%64,(a+1)*64+i) for a in range(len(profile)-1) for i in range(64)]
        mesh = bpy.data.meshes.new("Lathed vessel")
        mesh.from_pydata(verts, [], faces)
        obj = bpy.data.objects.new("Vessel", mesh)
        bpy.context.collection.objects.link(obj)
        finish(obj, mat, 0)
    elif spec["recipe"] == "robot":
        cube("Body", (0,0,.9), (.7,.42,.7), mat)
        cube("Head", (0,0,1.53), (.65,.46,.44), mat)
        cube("Face", (0,-.24,1.53), (.49,.025,.24), dark)
        for x in (-.23,.23):
            cube("Foot", (x,-.07,.1), (.27,.42,.2), dark)
            cube("Leg", (x,0,.37), (.18,.2,.4), mat)
        for x in (-.49,.49):
            cube("Arm", (x,0,.9), (.2,.25,.65), mat)
    else:
        for radius,depth,z in ((.6,.13,.065),(.32,.9,.58),(.5,.13,1.095)):
            bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=radius, depth=depth, location=(0,0,z))
            finish(bpy.context.object, mat)
else:
    bpy.ops.import_scene.gltf(filepath=spec["source"])

objects = [o for o in bpy.context.scene.objects if o.type == "MESH"]
if not objects:
    raise ValueError("Asset contains no mesh")
seen_ids = set()
for obj in objects:
    value = obj.get('lighthaus_object_id')
    if not isinstance(value, str) or len(value) != 32 or value in seen_ids:
        value = uuid.uuid4().hex
        obj['lighthaus_object_id'] = value
    seen_ids.add(value)
if spec["mode"] == "edit":
    operation, params = spec["operation"], spec["params"]
    targets = [o for o in objects if o.get('lighthaus_object_id') == params['object_id']] if params.get('object_id') else objects
    if not targets:
        raise ValueError('Selected object is missing from the imported asset')
    if operation == "material":
        mat = material(params["color"], params["roughness"], params["metallic"])
        for obj in targets:
            # Break linked mesh data so a targeted edit cannot affect another object.
            if obj.data.users > 1:
                obj.data = obj.data.copy()
            if 'material_slot' in params:
                slot = params['material_slot']
                if slot >= len(obj.data.materials):
                    raise ValueError('Selected material slot is missing')
                obj.data.materials[slot] = mat
            else:
                obj.data.materials.clear()
                obj.data.materials.append(mat)
                for polygon in obj.data.polygons:
                    polygon.material_index = 0
    elif operation == "decimate":
        for obj in targets:
            if obj.data.users > 1:
                obj.data = obj.data.copy()
            bpy.context.view_layer.objects.active = obj
            mod = obj.modifiers.new("Budget reduction", "DECIMATE")
            mod.ratio = params["ratio"]
            bpy.ops.object.modifier_apply(modifier=mod.name)
    elif operation == "normalize":
        points = [o.matrix_world @ Vector(c) for o in objects for c in o.bound_box]
        lo = Vector(tuple(min(p[i] for p in points) for i in range(3)))
        hi = Vector(tuple(max(p[i] for p in points) for i in range(3)))
        scale = params["height"] / max(hi.z-lo.z, .0001)
        center = Vector(((hi.x+lo.x)/2,(hi.y+lo.y)/2,lo.z))
        # Apply in world space so imported parent transforms do not distort dimensions.
        from mathutils import Matrix
        transform = Matrix.Scale(scale,4) @ Matrix.Translation(-center)
        for obj in objects:
            world = obj.matrix_world.copy()
            obj.parent = None
            obj.matrix_world = transform @ world
    else:
        raise ValueError("Unsupported operation")

bpy.ops.object.select_all(action="DESELECT")
for obj in objects:
    obj.select_set(True)
bpy.context.view_layer.objects.active = objects[0]
bpy.ops.export_scene.gltf(filepath=str(folder / "asset.glb"), export_format="GLB", use_selection=True, export_apply=True, export_extras=True)
triangles = sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in objects)
points = [o.matrix_world @ Vector(c) for o in objects for c in o.bound_box]
lo = Vector(tuple(min(p[i] for p in points) for i in range(3)))
hi = Vector(tuple(max(p[i] for p in points) for i in range(3)))
metrics = {"triangles": triangles, "objects": len(objects), "materials": len({m.name for o in objects for m in o.data.materials if m}), "dimensions_m": list(hi-lo)}
inventory = [{'id': o['lighthaus_object_id'], 'name': o.name,
              'triangles': sum(len(p.vertices)-2 for p in o.data.polygons),
              'materials': [{'slot': i, 'name': m.name if m else '(empty)'} for i,m in enumerate(o.data.materials)]} for o in objects]
(folder / "metrics.json").write_text(json.dumps({"geometry":metrics,"objects":inventory,"blender_version":bpy.app.version_string}), encoding="utf-8")

# Persist an editable scene before adding preview-only staging.
bpy.ops.wm.save_as_mainfile(filepath=str(folder / "asset.blend"))
center = (lo+hi)/2
extent = max(hi-lo)
bpy.ops.object.camera_add(location=center+Vector((2.3,-3.2,1.6))*extent)
camera = bpy.context.object
camera.rotation_euler = (center-camera.location).to_track_quat("-Z","Y").to_euler()
camera.data.type = "ORTHO"
camera.data.ortho_scale = extent*1.65
bpy.context.scene.camera = camera
for offset,power,size in (((-3,-4,5),1200,4),((4,-1,3),900,3),((0,4,4),1300,3)):
    bpy.ops.object.light_add(type="AREA", location=center+Vector(offset)*extent)
    light = bpy.context.object
    light.data.energy = power*extent*extent
    light.data.shape = "DISK"
    light.data.size = size*extent
    light.rotation_euler = (center-light.location).to_track_quat("-Z","Y").to_euler()
scene = bpy.context.scene
scene.render.engine = "CYCLES"
scene.cycles.device = "CPU"
scene.cycles.samples = 16
scene.render.resolution_x = 640
scene.render.resolution_y = 640
scene.render.resolution_percentage = 100
scene.render.film_transparent = True
scene.render.image_settings.file_format = "PNG"
scene.render.filepath = str(folder / "preview.png")
bpy.ops.render.render(write_still=True)
