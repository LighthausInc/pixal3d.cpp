"""Install this file as a Blender add-on, then use the Studio Link sidebar.

The background thread only performs authenticated loopback I/O. Every bpy
operation is dispatched by a main-thread application timer.
"""
bl_info = {'name': 'Lighthaus Studio Link', 'author': 'Lighthaus', 'version': (0,2,0),
           'blender': (4,2,0), 'location': 'View3D > Sidebar > Studio Link',
           'description': 'Connect a live Blender scene to 3DGen Studio', 'category': '3D View'}

import json
import math
import os
from pathlib import Path
import queue
import threading
import time
import urllib.request
from urllib.parse import urlsplit
import uuid
import bpy

_client = None
_main_thread = threading.main_thread().ident


def identity(obj):
    value = obj.get('lighthaus_object_id')
    if not isinstance(value, str) or len(value) != 32:
        value = uuid.uuid4().hex
        obj['lighthaus_object_id'] = value
    return value


def snapshot():
    seen = set()
    items = []
    for obj in bpy.context.scene.objects:
        if obj.type != 'MESH': continue
        key = identity(obj)
        if key in seen:
            obj['lighthaus_object_id'] = uuid.uuid4().hex
            key = identity(obj)
        seen.add(key)
        items.append({'id': key, 'name': obj.name, 'selected': obj.select_get(),
                      'triangles': sum(len(p.vertices)-2 for p in obj.data.polygons),
                      'location': list(obj.location), 'rotation': [math.degrees(v) for v in obj.rotation_euler],
                      'scale': list(obj.scale), 'modifiers': [{'name': m.name, 'type': m.type} for m in obj.modifiers],
                      'materials': [{'slot': i, 'name': m.name if m else '(empty)'} for i,m in enumerate(obj.data.materials)]})
    return {'objects': items, 'blender_version': bpy.app.version_string, 'execution_thread': threading.current_thread().name}


def scoped_path(value, state, source=False):
    file = Path(value).resolve()
    if not file.is_relative_to(state):
        raise ValueError('Studio file is outside the connected state directory')
    if source and (file.name != 'asset.glb' or file.parent.parent != state):
        raise ValueError('Only registered Studio GLB assets may be imported')
    if not source and (file.parent != state/'live-exports' or file.suffix != '.glb'):
        raise ValueError('Export destination is outside Studio exports')
    return file


def execute(command, state):
    if threading.current_thread().ident != _main_thread:
        raise RuntimeError('Blender operations must execute on the main thread')
    op, args = command['operation'], command['args']
    # Repair IDs copied by manual Blender duplicate before accepting any target.
    snapshot()
    objects = [o for o in bpy.context.scene.objects if o.type == 'MESH']
    wanted = args.get('object_ids', [])
    targets = [o for o in objects if identity(o) in wanted]
    if wanted and len(targets) != len(wanted):
        raise ValueError('A target object is missing; inspect the scene again')
    if op == 'inspect':
        return {'snapshot': snapshot()}
    if bpy.context.mode != 'OBJECT':
        raise ValueError('Switch Blender to Object Mode before using Studio Link')
    active = bpy.context.view_layer.objects.active
    selected = list(bpy.context.selected_objects)
    result = {}
    try:
        if op == 'import_asset':
            source = scoped_path(args['source'], state, source=True)
            before = set(bpy.data.objects)
            bpy.ops.import_scene.gltf(filepath=str(source))
            imported = [o for o in bpy.data.objects if o not in before]
            collection = bpy.data.collections.new('Studio · '+args['name'])
            bpy.context.scene.collection.children.link(collection)
            for obj in imported:
                for old in list(obj.users_collection): old.objects.unlink(obj)
                collection.objects.link(obj)
                if obj.type == 'MESH':
                    obj['lighthaus_object_id'] = uuid.uuid4().hex
                    obj['lighthaus_source_job_id'] = args['job_id']
            result['imported_ids'] = [identity(o) for o in imported if o.type=='MESH']
        elif op == 'create_primitive':
            shape = args['shape']
            if shape == 'cube': bpy.ops.mesh.primitive_cube_add(size=1, location=args['location'])
            elif shape == 'sphere': bpy.ops.mesh.primitive_uv_sphere_add(segments=32, ring_count=16, radius=.5, location=args['location'])
            elif shape == 'cylinder': bpy.ops.mesh.primitive_cylinder_add(vertices=32, radius=.5, depth=1, location=args['location'])
            else: raise ValueError('Unsupported primitive')
            obj = bpy.context.object
            obj.name = args['name']
            result['created_id'] = identity(obj)
        elif op == 'transform':
            for obj in targets:
                obj.location = args['location']
                obj.rotation_mode = 'XYZ'
                obj.rotation_euler = [math.radians(v) for v in args['rotation']]
                obj.scale = args['scale']
        elif op == 'material':
            slot = args['material_slot']
            if any(slot >= len(o.data.materials) and not (slot==0 and len(o.data.materials)==0) for o in targets):
                raise ValueError('Material slot is missing on a target object')
            mat = bpy.data.materials.new('Studio material')
            mat.use_nodes = True
            shader = mat.node_tree.nodes.get('Principled BSDF')
            def linear(v): return v/12.92 if v <= .04045 else ((v+.055)/1.055)**2.4
            shader.inputs['Base Color'].default_value = tuple(linear(int(args['color'][i:i+2],16)/255) for i in (1,3,5))+(1,)
            shader.inputs['Roughness'].default_value = args['roughness']
            shader.inputs['Metallic'].default_value = args['metallic']
            for obj in targets:
                if obj.data.users > 1: obj.data = obj.data.copy()
                if obj.data.materials: obj.data.materials[slot] = mat
                else: obj.data.materials.append(mat)
        elif op == 'decimate':
            for obj in targets:
                mod = obj.modifiers.new('Studio reduction '+command['id'][:6], 'DECIMATE')
                mod.ratio = args['ratio']
            result['note'] = 'Non-destructive modifiers added; original mesh data is retained'
        elif op == 'export_asset':
            dest = scoped_path(args['destination'], state)
            bpy.ops.object.select_all(action='DESELECT')
            for obj in targets: obj.select_set(True)
            bpy.context.view_layer.objects.active = targets[0]
            bpy.ops.export_scene.gltf(filepath=str(dest), export_format='GLB', use_selection=True, export_apply=True, export_extras=True)
            result['source_job_ids'] = sorted({o.get('lighthaus_source_job_id') for o in targets if o.get('lighthaus_source_job_id')})
        else:
            raise ValueError('Unsupported operation; arbitrary Python is not accepted')
        bpy.context.view_layer.update()
        if op != 'export_asset' and bpy.ops.ed.undo_push.poll():
            bpy.ops.ed.undo_push(message='Studio Link: '+op)
    finally:
        # Keep the user's selection for refinement/export. New/imported objects
        # intentionally retain Blender's normal selection behavior.
        if op not in ('import_asset', 'create_primitive'):
            bpy.ops.object.select_all(action='DESELECT')
            for obj in selected:
                if obj.name in bpy.context.view_layer.objects: obj.select_set(True)
            if active and active.name in bpy.context.view_layer.objects:
                bpy.context.view_layer.objects.active = active
    result['snapshot'] = snapshot()
    return result


class LinkClient:
    def __init__(self, session_file):
        path = Path(session_file).expanduser().resolve()
        session = json.loads(path.read_text())
        parsed = urlsplit(session['url'])
        if parsed.scheme != 'http' or parsed.hostname != '127.0.0.1' or parsed.path not in ('','/') or parsed.query or parsed.fragment or parsed.username:
            raise ValueError('Choose a local Studio session.json file')
        self.base = session['url'].rstrip('/')
        self.token = session['token']
        self.state = path.parent
        self.peer = uuid.uuid4().hex
        self.version = bpy.app.version_string
        self.inbox = queue.Queue()
        self.outbox = queue.Queue()
        self.stop = threading.Event()
        self.status = 'Connecting'
        self.thread = threading.Thread(target=self.network, daemon=True, name='Studio Link I/O')

    def request(self, endpoint, data):
        request = urllib.request.Request(self.base+'/api/blender/'+endpoint, json.dumps(data).encode(),
                 {'Authorization':'Bearer '+self.token, 'Content-Type':'application/json'})
        # Never use a proxy for the authenticated loopback connection.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(request, timeout=5) as response:
            return json.loads(response.read(2_100_000))

    def network(self):
        try:
            self.request('connect', {'peer_id':self.peer, 'version':self.version})
            self.status = 'Connected'
        except Exception:
            self.status = 'Connection failed. Check Studio and the selected session file.'
            return
        pending = None
        while not self.stop.is_set():
            try:
                if pending is None:
                    try: pending = self.outbox.get_nowait()
                    except queue.Empty: pass
                if pending is not None:
                    self.request('complete', pending)
                    pending = None
                value = self.request('poll', {'peer_id':self.peer})
                if value.get('command'): self.inbox.put(value['command'])
                self.status = 'Connected'
            except Exception:
                self.status = 'Connection interrupted; edits are not replayed'
            self.stop.wait(.4)
        try: self.request('disconnect', {'peer_id': self.peer})
        except Exception: pass

    def pump(self):
        if self.stop.is_set(): return None
        try: command = self.inbox.get_nowait()
        except queue.Empty: return .1
        response = {'peer_id':self.peer, 'command_id':command['id']}
        try: response['result'] = execute(command, self.state)
        except Exception as exc: response['error'] = str(exc)[:300]
        self.outbox.put(response)
        return .1

    def start(self):
        self.thread.start()
        bpy.app.timers.register(self.pump, first_interval=.1)

    def close(self):
        self.stop.set()
        if bpy.app.timers.is_registered(self.pump): bpy.app.timers.unregister(self.pump)
        self.thread.join(timeout=6)
        self.token = ''


class LH3D_Connect(bpy.types.Operator):
    bl_idname = 'lh3d.connect'
    bl_label = 'Connect to Studio'
    def execute(self, context):
        global _client
        try:
            if _client: _client.close()
            _client = LinkClient(context.scene.lh3d_session_file)
            _client.start()
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc)[:200])
            return {'CANCELLED'}


class LH3D_Disconnect(bpy.types.Operator):
    bl_idname = 'lh3d.disconnect'
    bl_label = 'Disconnect'
    def execute(self, context):
        global _client
        if _client: _client.close()
        _client = None
        return {'FINISHED'}


class LH3D_Panel(bpy.types.Panel):
    bl_label = 'Lighthaus Studio Link'
    bl_idname = 'LH3D_PT_link'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Studio Link'
    def draw(self, context):
        self.layout.prop(context.scene, 'lh3d_session_file')
        self.layout.label(text=_client.status if _client else 'Disconnected')
        self.layout.operator('lh3d.disconnect' if _client else 'lh3d.connect')
        self.layout.label(text='Scene edits run on Blender’s main thread.')


_classes = (LH3D_Connect, LH3D_Disconnect, LH3D_Panel)
def register():
    for cls in _classes: bpy.utils.register_class(cls)
    root = Path(os.getenv('LOCALAPPDATA', str(Path.home())))/'Lighthaus3DGen' if os.name=='nt' else Path.home()/'Library/Application Support/Lighthaus3DGen'
    bpy.types.Scene.lh3d_session_file = bpy.props.StringProperty(name='Studio session', subtype='FILE_PATH', default=str(root/'session.json'), options={'SKIP_SAVE'})


def unregister():
    global _client
    if _client: _client.close()
    _client = None
    del bpy.types.Scene.lh3d_session_file
    for cls in reversed(_classes): bpy.utils.unregister_class(cls)


if __name__ == '__main__': register()
