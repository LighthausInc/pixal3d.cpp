#!/bin/bash
set -eu
cd "$(dirname "$0")"
export LH3D_PYTHON="${LH3D_PYTHON:-$(command -v python3)}"
# Upstream GGML Metal needs F16 K/V on M1 instead of its default BF16 path.
if [[ "$(sysctl -n machdep.cpu.brand_string)" == *"Apple M1"* ]]; then
  export TRELLIS_FA_FAST="${TRELLIS_FA_FAST:-1}"
fi
npm start
