"""Run the same robot image/seed through native TRELLIS and preserve evidence.

No cloud provider or model download is invoked. Default needs a configured,
verified native runtime and Blender. Reports actual platform and backend logs.
"""
import argparse
import base64
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import time
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'backend'))
from core import Studio
from native import sha256
from runtime_settings import load_runtime


def hardware():
    result={'system':platform.system(),'release':platform.release(),'machine':platform.machine(),'python':platform.python_version()}
    if sys.platform=='darwin':
        for key,name in [('cpu','machdep.cpu.brand_string'),('memory_bytes','hw.memsize')]:
            result[key]=subprocess.check_output(['/usr/sbin/sysctl','-n',name],text=True).strip()
        result['macos']=platform.mac_ver()[0]
    elif shutil.which('nvidia-smi'):
        result['gpu']=subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.total,driver_version','--format=csv,noheader'],text=True).strip()
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--image',type=Path,default=root/'benchmarks/aster-reference.png')
    parser.add_argument('--resolution',type=int,choices=[512,1024],default=512)
    parser.add_argument('--seed',type=int,default=42)
    parser.add_argument('--timeout',type=int,default=3600)
    args=parser.parse_args()
    if not 60<=args.timeout<=7200:raise ValueError('Choose a timeout from 60–7200 seconds')
    load_runtime()
    out=args.output.expanduser().resolve()
    if (out/'benchmark.json').exists():raise ValueError('Choose a new output directory to preserve the previous benchmark')
    studio=Studio(out/'state')
    try:
        raw={'provider':'trellis','prompt':'Aster native benchmark','data_class':'synthetic',
             'resolution':args.resolution,'seed':args.seed,'image_base64':base64.b64encode(args.image.read_bytes()).decode()}
        job=studio.submit(raw)
        print('Job '+job['id']+' submitted',flush=True)
        deadline=time.monotonic()+args.timeout
        stage=None
        while job['status'] in ('queued','running'):
            if job['stage']!=stage:
                stage=job['stage'];print(stage,flush=True)
            if time.monotonic()>deadline:
                studio.cancel(job['id']);raise TimeoutError('Benchmark exceeded its configured timeout')
            time.sleep(.5)
            job=studio.get(job['id'])
        folder=studio.state/job['id']
        log=(folder/'worker.log').read_text(encoding='utf-8',errors='replace') if (folder/'worker.log').exists() else ''
        engine_time=re.search(r'done in ([0-9.]+)s',log)
        backend='metal' if re.search(r'ggml_metal|Metal GPU|backend:? Metal',log,re.I) else 'cuda' if 'ggml_cuda_init' in log else 'unverified'
        backend_evidence=[line for line in log.splitlines() if ('metal' if backend=='metal' else 'cuda') in line.lower()][:40]
        report={'hardware':hardware(),'job_id':job['id'],'status':job['status'],'error':job.get('error'),
                'resolution':args.resolution,'seed':args.seed,'input_sha256':sha256(args.image),
                'elapsed_total_s':job.get('elapsed'),'engine_s':float(engine_time[1]) if engine_time else None,
                'backend':backend,'backend_evidence':backend_evidence,
                'require_gpu':True,'native':job.get('native'),'geometry':job.get('metrics'),
                'memory_note':'Windows peak resident memory is not measured by this runner.'}
        if sys.platform=='darwin':
            import resource
            report['peak_child_rss_bytes']=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
            report['memory_note']='macOS ru_maxrss: maximum resident memory across completed child processes, including native engine and Blender; not GPU allocation.'
        for name in ('asset.glb','asset.blend','preview.png','asset.provenance.json','worker.log'):
            if (folder/name).exists():shutil.copy2(folder/name,out/name)
        (out/'benchmark.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        print(json.dumps({k:report[k] for k in ('status','backend','engine_s','elapsed_total_s','geometry')},indent=2),flush=True)
        if job['status']!='succeeded':raise RuntimeError(job.get('error','Native generation failed'))
        if not backend_evidence:raise RuntimeError('Result saved, but the worker log does not establish the requested GPU backend')
    finally:studio.close()


if __name__=='__main__':main()
