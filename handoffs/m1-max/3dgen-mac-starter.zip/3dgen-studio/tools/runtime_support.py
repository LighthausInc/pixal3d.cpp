"""Small, dependency-free primitives shared by native setup tooling."""
import hashlib
import json
from pathlib import Path
import time
import urllib.request


def digest(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(8*1024*1024),b''):value.update(block)
    return value.hexdigest()


def download(item, directory):
    output=Path(directory)/item['name']
    if output.parent.resolve()!=Path(directory).resolve():
        raise ValueError('Invalid download filename')
    output.parent.mkdir(parents=True,exist_ok=True)
    if output.is_file() and output.stat().st_size==item['size_bytes'] and digest(output)==item['sha256']:
        print('Verified existing '+output.name,flush=True)
        return output
    partial=output.with_suffix(output.suffix+'.part')
    offset=partial.stat().st_size if partial.exists() else 0
    if offset>item['size_bytes']:raise ValueError('Oversized partial file: '+str(partial))
    if offset==item['size_bytes']:
        if digest(partial)!=item['sha256']:raise ValueError('Partial file failed SHA-256: '+str(partial))
        partial.replace(output)
        return output
    url=item['url']+('&' if '?' in item['url'] else '?')+'download=true&lh3d='+str(int(time.time()))
    request=urllib.request.Request(url,headers={'Range':f'bytes={offset}-'} if offset else {})
    with urllib.request.urlopen(request,timeout=90) as response:
        resume=offset>0 and response.status==206
        if resume and not response.headers.get('Content-Range','').startswith(f'bytes {offset}-'):
            raise ValueError('Invalid Content-Range from download server')
        count=offset if resume else 0
        next_report=count+256*1024*1024
        with partial.open('ab' if resume else 'wb') as stream:
            while block:=response.read(1024*1024):
                count+=len(block)
                if count>item['size_bytes']:raise ValueError('Download exceeds pinned size')
                stream.write(block)
                if count>=next_report:
                    print(f"{output.name}: {count*100/item['size_bytes']:.0f}%",flush=True)
                    next_report=count+256*1024*1024
    if partial.stat().st_size!=item['size_bytes'] or digest(partial)!=item['sha256']:
        raise ValueError('Download failed size or SHA-256 verification: '+str(partial))
    partial.replace(output)
    print('Verified '+output.name,flush=True)
    return output


def model_manifest(include_1024=False):
    source=Path(__file__).parent/'manifests/trellis2-q8.json'
    manifest=json.loads(source.read_text(encoding='utf-8'))
    if not include_1024:
        manifest['files']=[f for f in manifest['files'] if '_1024' not in f['name']]
    return manifest


def install_models(destination, include_1024=False):
    directory=Path(destination)
    manifest=model_manifest(include_1024)
    for item in manifest['files']:
        for attempt in range(3):
            try:
                download(item,directory)
                break
            except (OSError, TimeoutError):
                if attempt==2:raise
                time.sleep(2)
    # Write the manifest only after every selected file has passed verification.
    directory.mkdir(parents=True,exist_ok=True)
    temp=directory/'manifest.tmp'
    temp.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    temp.replace(directory/'manifest.json')
    return manifest
