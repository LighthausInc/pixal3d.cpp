"""Fetch a revision-pinned, SHA-verified native test runtime into this workspace."""
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
from pathlib import Path
import time
import urllib.request
import zipfile

parser = argparse.ArgumentParser(description='Install the pinned Windows CUDA test engine and Q8 GGUF weights (~10 GB).')
parser.add_argument('--destination', type=Path, required=True)
args = parser.parse_args()
DEST = args.destination.resolve()
MODELS = DEST / 'trellis-q8'
MODELS.mkdir(parents=True,exist_ok=True)
REV = 'a57397bd3d351599d9729fc144b3f87c3f87d65b'
def get_json(url):
    with urllib.request.urlopen(url,timeout=60) as response:
        return json.load(response)
files = get_json(f'https://huggingface.co/api/models/ilintar/trellis2-gguf/tree/{REV}/q8?expand=true')
manifest = {'schema_version':1,'id':'trellis2-q8','provider':'trellis','revision':REV,'engine_version':'v0.8.1',
            'source':'https://huggingface.co/ilintar/trellis2-gguf','license_status':'source-specific terms; commercial review pending',
            'files':[{'name':Path(f['path']).name,'size_bytes':f['size'],'sha256':f['lfs']['oid'],
                      'url':f"https://huggingface.co/ilintar/trellis2-gguf/resolve/{REV}/{f['path']}"} for f in files if f['type']=='file']}
(MODELS/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
def digest(file):
    h=hashlib.sha256()
    with file.open('rb') as source:
        while chunk:=source.read(8*1024*1024):h.update(chunk)
    return h.hexdigest()
def download(item):
    output=Path(item['output']) if 'output' in item else MODELS/item['name']
    if output.exists() and output.stat().st_size==item['size_bytes'] and digest(output)==item['sha256']:
        print('VERIFIED existing '+item['name'],flush=True);return
    part=output.with_suffix(output.suffix+'.part')
    for attempt in range(4):
        offset=part.stat().st_size if part.exists() else 0
        if offset == item['size_bytes']:
            if digest(part) == item['sha256']:
                part.replace(output); return
            raise RuntimeError('Complete partial file failed integrity verification: '+str(part))
        if offset>item['size_bytes']:
            raise RuntimeError('Oversized partial download '+item['name'])
        try:
            request=urllib.request.Request(item['url']+'?download=true&lh3d='+str(int(time.time())),headers={'Range':f'bytes={offset}-'} if offset else {})
            with urllib.request.urlopen(request,timeout=60) as response:
                resume=offset>0 and response.status==206
                if resume and not response.headers.get('Content-Range','').startswith(f'bytes {offset}-'):
                    raise RuntimeError('Invalid resume response')
                size=offset if resume else 0
                next_report=size+256*1024*1024
                with part.open('ab' if resume else 'wb') as target:
                    while chunk:=response.read(1024*1024):
                        target.write(chunk);size+=len(chunk)
                        if size>item['size_bytes']:raise RuntimeError('Download exceeded expected size')
                        if size>=next_report:
                            print(f"DOWNLOAD {item['name']} {size*100/item['size_bytes']:.0f}%",flush=True)
                            next_report=size+256*1024*1024
            if part.stat().st_size!=item['size_bytes'] or digest(part)!=item['sha256']:
                raise RuntimeError('Integrity check failed for '+item['name'])
            part.replace(output)
            print('VERIFIED '+item['name'],flush=True)
            return
        except Exception as error:
            print(f"RETRY {item['name']} {type(error).__name__}: {error}",flush=True)
            if attempt==3:raise
            time.sleep(2)
binary={'name':'trellis-cuda-windows-x64.zip','output':str(DEST/'trellis-cuda-windows-x64.zip'),
        'size_bytes':715040905,'sha256':'d2ea7b57174d3bff438064faf0b5fbcc55c29c31e6bba5f41030936fa366ed48',
        'url':'https://github.com/pwilkin/trellis.cpp/releases/download/v0.8.1/trellis-cuda-windows-x64.zip'}
download(binary)
runtime=DEST/'trellis-v0.8.1-cuda'
runtime.mkdir(exist_ok=True)
with zipfile.ZipFile(binary['output']) as archive:
    for name in archive.namelist():
        candidate=(runtime/name).resolve()
        if not candidate.is_relative_to(runtime.resolve()):raise RuntimeError('Archive traversal')
    archive.extractall(runtime)
print('ENGINE extracted '+str(runtime),flush=True)
with ThreadPoolExecutor(max_workers=3) as executor:
    list(executor.map(download,manifest['files']))
(DEST/'installation.json').write_text(json.dumps({'engine':binary,'model_manifest':str(MODELS/'manifest.json'), 'verified_at':time.time()},indent=2),encoding='utf8')
print('INSTALLATION VERIFIED',flush=True)
