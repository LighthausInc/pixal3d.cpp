"""Render a neutral edge overlay and measure geometry using a fixed comparison camera.

Run inside Blender: --background --factory-startup --python inspect-topology.py -- spec.json
The spec supplies source, output_dir and label. Source is loaded as GLB with autoexec disabled.
"""
import json
from pathlib import Path
import sys
import bpy
from mathutils import Vector

spec = json.loads(Path(sys.argv[sys.argv.index('--') + 1]).read_text())
out = Path(spec['output_dir'])
out.mkdir(parents=True, exist_ok=True)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=spec['source'])
objects = [o for o in bpy.context.scene.objects if o.type == 'MESH']
stats = {'label': spec['label'], 'triangles': 0, 'vertices': 0, 'faces': 0, 'quads': 0,
         'boundary_edges': 0, 'nonmanifold_edges': 0, 'components': 0, 'uv_layers': 0,
         'note': 'Topology counts on imported GLB. UV/material seam vertex splits can inflate boundary/component counts.'}
for obj in objects:
    mesh = obj.data
    stats['triangles'] += sum(len(p.vertices)-2 for p in mesh.polygons)
    stats['vertices'] += len(mesh.vertices)
    stats['faces'] += len(mesh.polygons)
    stats['quads'] += sum(len(p.vertices)==4 for p in mesh.polygons)
    stats['uv_layers'] += len(mesh.uv_layers)
    edges = {}
    parents = list(range(len(mesh.vertices)))
    def root(i):
        while parents[i] != i:
            parents[i] = parents[parents[i]]
            i = parents[i]
        return i
    for p in mesh.polygons:
        for a,b in p.edge_keys:
            edge = (min(a,b), max(a,b))
            edges[edge] = edges.get(edge, 0)+1
            ra,rb = root(a),root(b)
            if ra != rb: parents[ra] = rb
    stats['boundary_edges'] += sum(n==1 for n in edges.values())
    stats['nonmanifold_edges'] += sum(n>2 for n in edges.values())
    stats['components'] += len({root(i) for i in range(len(parents))})
    mesh.materials.clear()
    mat = bpy.data.materials.new('Neutral mesh with edge overlay')
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    bsdf = nodes.get('Principled BSDF')
    bsdf.inputs['Roughness'].default_value = .75
    wire = nodes.new('ShaderNodeWireframe')
    wire.use_pixel_size = True
    wire.inputs['Size'].default_value = .65
    mix = nodes.new('ShaderNodeMixRGB')
    mix.inputs[1].default_value = (.36,.55,.59,1)
    mix.inputs[2].default_value = (.012,.025,.03,1)
    links.new(wire.outputs['Fac'],mix.inputs[0])
    links.new(mix.outputs[0],bsdf.inputs['Base Color'])
    mesh.materials.append(mat)
    for p in mesh.polygons: p.material_index=0
points=[o.matrix_world @ Vector(c) for o in objects for c in o.bound_box]
lo=Vector(tuple(min(p[i] for p in points) for i in range(3)))
hi=Vector(tuple(max(p[i] for p in points) for i in range(3)))
stats['dimensions_m']=list(hi-lo)
stats['center_m']=list((lo+hi)/2)
(out/'topology.json').write_text(json.dumps(stats,indent=2))
# Aster source bounds, held constant across comparison variants.
center=Vector(spec.get('center_m', (lo+hi)/2))
extent=1
bpy.ops.object.camera_add(location=center+Vector((2.3,-3.2,1.6))*extent)
camera=bpy.context.object
camera.rotation_euler=(center-camera.location).to_track_quat('-Z','Y').to_euler()
camera.data.type='ORTHO'
camera.data.ortho_scale=1.65
bpy.context.scene.camera=camera
for offset,power,size in (((-3,-4,5),1200,4),((4,-1,3),900,3),((0,4,4),1300,3)):
    bpy.ops.object.light_add(type='AREA', location=center+Vector(offset))
    light=bpy.context.object
    light.data.energy=power
    light.data.shape='DISK'
    light.data.size=size
    light.rotation_euler=(center-light.location).to_track_quat('-Z','Y').to_euler()
scene=bpy.context.scene
scene.render.engine='CYCLES'
scene.cycles.device='CPU'
scene.cycles.samples=24
scene.render.resolution_x=1000
scene.render.resolution_y=1000
scene.render.resolution_percentage=100
scene.render.film_transparent=True
scene.render.image_settings.file_format='PNG'
scene.render.filepath=str(out/'wireframe.png')
bpy.ops.render.render(write_still=True)
