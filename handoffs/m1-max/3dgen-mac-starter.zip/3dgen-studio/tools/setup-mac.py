"""Build the pinned Metal engine and configure a user-owned app runtime.

Run with native arm64 Python on macOS. --plan works on any OS without writes.
System dependencies are diagnosed, never installed or elevated automatically.
"""
import argparse
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
from runtime_support import digest, install_models, model_manifest

ENGINE_COMMIT='367f06722e6c482d8a46d94509be326409066d4a'
GGML_COMMIT='f8697b33795db2ee6a2569b40853ca6aaa69f9b9'
DEFAULT_DEST=Path.home()/'Library/Application Support/Lighthaus3DGen/native-runtime'


def run(args, **kwargs):
    print('Running: '+' '.join(map(str,args)),flush=True)
    return subprocess.run(args,check=True,text=True,**kwargs)


def preflight():
    if sys.version_info<(3,11):raise ValueError('Python 3.11 or newer is required')
    if sys.platform!='darwin' or platform.machine()!='arm64':
        raise ValueError('Run setup with native arm64 Python on an Apple Silicon Mac; Rosetta/x86_64 is unsupported')
    missing=[name for name in ('git','cmake','ninja','clang','xcrun') if not shutil.which(name)]
    if missing:raise ValueError('Install missing build tools first: '+', '.join(missing)+'. See docs/MAC-VALIDATION.md.')
    run(['xcrun','--find','metal'],capture_output=True)


def build_engine(destination, jobs):
    source=destination/'trellis-source'
    if not source.exists():
        run(['git','clone','--no-checkout','https://github.com/pwilkin/trellis.cpp',str(source)])
    elif not (source/'.git').exists():
        raise ValueError('Existing engine source directory is not a Git checkout')
    remote=run(['git','-C',str(source),'remote','get-url','origin'],capture_output=True).stdout.strip()
    if remote!='https://github.com/pwilkin/trellis.cpp':raise ValueError('Unexpected engine repository origin')
    dirty=run(['git','-C',str(source),'status','--porcelain','--untracked-files=no'],capture_output=True).stdout
    # A --no-checkout clone initially reports deleted files until checkout.
    if (source/'CMakeLists.txt').exists() and dirty:raise ValueError('Engine source has local changes; preserve or resolve them before setup')
    run(['git','-C',str(source),'fetch','origin',ENGINE_COMMIT])
    run(['git','-C',str(source),'checkout','--detach',ENGINE_COMMIT])
    run(['git','-C',str(source),'submodule','update','--init','--recursive'])
    actual=run(['git','-C',str(source/'thirdparty/ggml'),'rev-parse','HEAD'],capture_output=True).stdout.strip()
    if actual!=GGML_COMMIT:raise ValueError('GGML submodule does not match the pinned commit')
    build=source/'build-studio-metal'
    # PNG output avoids an additional configure-time libwebp download. The
    # neural model, weights and seed remain the same as the Windows benchmark.
    run(['cmake','-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
         '-DCMAKE_OSX_ARCHITECTURES=arm64','-DGGML_METAL=ON','-DGGML_CUDA=OFF','-DGGML_VULKAN=OFF','-DTRELLIS_WEBP=OFF'])
    run(['cmake','--build',str(build),'--target','trellis-cli','--parallel',str(jobs)])
    binary=build/'trellis-cli'
    if not binary.is_file():raise ValueError('Build did not produce trellis-cli')
    run(['lipo','-verify_arch','arm64',str(binary)])
    return binary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination',type=Path,default=DEFAULT_DEST)
    parser.add_argument('--include-1024',action='store_true')
    parser.add_argument('--jobs',type=int,default=min(os.cpu_count() or 4,8))
    parser.add_argument('--plan',action='store_true')
    args=parser.parse_args()
    manifest=model_manifest(args.include_1024)
    plan={'platform':'macOS arm64 / Metal','engine_commit':ENGINE_COMMIT,'ggml_commit':GGML_COMMIT,
          'model_revision':manifest['revision'],'model_bytes':sum(f['size_bytes'] for f in manifest['files']),
          'files':[f['name'] for f in manifest['files']], 'destination':str(args.destination),
          'prerequisites':['native Python 3.11+','git','CMake','Ninja','Xcode Metal compiler','Blender (for inspection)'],
          'm1_attention':'TRELLIS_FA_FAST=1','texture_encoding':'PNG'}
    if args.plan:
        print(json.dumps(plan,indent=2));return
    if not 1<=args.jobs<=64:raise ValueError('Choose 1–64 build jobs')
    preflight()
    dest=args.destination.expanduser().resolve();dest.mkdir(parents=True,exist_ok=True)
    binary=build_engine(dest,args.jobs)
    models=dest/'trellis-q8'
    install_models(models,args.include_1024)
    installed={**plan,'binary':str(binary),'binary_sha256':digest(binary),'models':str(models),'configured':True}
    (dest/'installation.json').write_text(json.dumps(installed,indent=2),encoding='utf-8')
    settings=DEFAULT_DEST.parent/'runtime.json'
    settings.parent.mkdir(parents=True,exist_ok=True)
    config=json.loads(settings.read_text(encoding='utf-8')) if settings.exists() else {}
    config.update(TRELLIS_BIN=str(binary),TRELLIS_MODELS=str(models),LH3D_PYTHON=sys.executable)
    if shutil.which('node'):config['LH3D_NODE']=shutil.which('node')
    settings.write_text(json.dumps(config,indent=2),encoding='utf-8')
    print('Metal runtime built and weights verified. Run tools/benchmark-native.py on this Mac to verify inference.',flush=True)


if __name__=='__main__':
    try:main()
    except (ValueError,subprocess.CalledProcessError) as exc:
        print('Setup stopped: '+str(exc),file=sys.stderr);sys.exit(1)
